#include <stdio.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

void getinfo(int sock)
 {
   FILE *surs,*aux;
   char *user,*nume,*director,*ceva,*com;
   int size=1000;
   surs=popen("sed  \"s/^\\(.*\\):\\(.*\\):\\(.*\\):\\(.*\\):\\(.*\\):\\(.*\\):\\(.*\\)$/\\1:\\5:\\6/g\" /etc/passwd | tr ':' '\\n'","r");
   user=(char *)malloc (size*sizeof(char));
   nume=(char *)malloc (size*sizeof(char));
   director=(char *)malloc (size*sizeof(char));
   ceva=(char *)malloc (size*sizeof(char));
   com=(char *)malloc (size*sizeof(char));
   while (!feof(surs))
    {
     strcpy(user,"\0");
     strcpy(nume,"\0");
     strcpy(director,"\0");
     fgets(user,size,surs);
     fgets(nume,size,surs);
     fgets(director,size,surs);
     if (strcmp(user,"\0"))
       {
          user[strlen(user)-1]='\0';
          nume[strlen(nume)-1]='\0';
          director[strlen(director)-1]='\0';
          sprintf(com,"ls %s/public_html/ 2>/dev/null| grep \"index.html\" 2>/dev/null ",director);
          aux=popen(com,"r");
          strcpy(ceva,"");
          fgets(ceva,size,aux);
          if (strstr(ceva,"index.html"))
               strcpy(ceva,"Are pagina!");
          else
               strcpy(ceva," ");
//          printf(" %s %s server %s \n",nume,user,ceva);
          sprintf(com,"(\"%s\",\"%s\",\"server\",\"email\",\"%s\")",nume,user,ceva);
          if (write(sock,com,strlen(com))<=0) {
              pclose(surs);
              exit(1);
          }
          pclose(aux);
       }
    }
  pclose(surs);
 }


int main()
{
         long  timp;
        int sd, comm,n,fd;
        int pid_c;
        char fis_cli[200];
        char buf[200];

        struct sockaddr_in adr;
        bzero(&adr, sizeof(adr));
        if ((sd=socket(PF_INET, SOCK_STREAM, 0))==-1)
         {
             perror("socket()");
             exit(1);
         }
        adr.sin_family=AF_INET;
        adr.sin_addr.s_addr=htons(INADDR_ANY); /* adresa masinii locale */
        adr.sin_port=htons(55555);
        if (bind(sd,(struct sockaddr*)&adr,sizeof(adr))==-1)
           {      
             perror("bind()");
             exit(1); 
           } 
        if (listen(sd,5)==-1)
           {
             perror("listen()");
             exit(1);
           }

        printf("\nAstept clienti...astept...\n");
        for (;;)
        {
        if ((comm=accept(sd,NULL,NULL))==-1)
          {
            perror("accept()");
            exit(1);
          }
        printf("\nAccept client...\n ");
        getinfo(comm); 
        close(comm);
        }
        close(sd);

        
 // getinfo(4);
  return 0;
}

/*
              SUBIECT: Programare functionala si logica
                AUTOR: Petrascu Dragos <pd7936@scs.ubbcluj.ro>, grupa 224
        DATA PREDARII: 19 martie 1999

  CODUL LABORATORULUI: C1
     DESCRIEREA TEMEI: Programare recursiva cu liste liniare in
                       limbajele C si Pascal
           PROBLEMA 9: Sa se scrie programe in C sau Pascal ce vor utiliza
                       functii sau proceduri recursive cu urmatoarele
                       cerinte:
                       a. Sa se testeze egalitatea a doua liste.
                       b. Sa se determine intersectia a doua multimi(liste).
                       OBS: Crearea, listarea si eliminarea listelor se va
                       face tot recursiv.

*/

#include <stdio.h>
#include <alloc.h>

typedef struct Nod		/* structura unui nod din lista		*/
{
  int           inf;		/* campul informatie			*/
  struct Nod*   leg;		/* campul legatura catre nodul urmator	*/
} nod;

nod* creare(void);
/*
   Creaza o lista si aloca memorie pentru aceasta.
   Intoarce adresa catre primul nod al listei.
*/

void distrug(nod*);
/*
   Elibereaza memoria alocata de o lista.
   Adresa primului nod al listei este data ca parametru.
*/

void listare(nod*);
/*
   Listeaza valorile campului informatie din nodurile listei.
   Adresa primului nod al listei este data ca parametru.
*/

int egal(nod*,nod*);
/*
   Testeaza egalitatea a doua liste.
   Intoarce 1 in caz de egalitate si 0 in caz de neegalitate.
   Adresa primului nod al primei listei este data ca prim parametru.
   Adresa primului nod al listei a doua este data ca parametru al doilea.
*/

int exista(int,nod*);
/*
   Testeaza existenta unei valori intr-o multime reprezentata ca lista.
   Intoarce 1 in caz de existenta si 0 in caz de neexistenta.
   Valoarea care se cauta in lista este data ca prim parametru.
   Adresa primului nod al listei este data ca parametru al doilea.
*/

nod* intersect(nod*,nod*);
/*
   Calculeaza intersectia a doua multimi reprezentate ca liste.
   Se aloca o noua lista. Aceasta va avea semnificatia multimii intersectie.
   Intoarce adresa catre primul nod al listei intersectie.
   Adresa primului nod al primei listei este data ca prim parametru.
   Adresa primului nod al listei a doua este data ca parametru al doilea.
*/

int main(void)
{
  nod *A,*B,*C;
  A=creare();
  B=creare();
  C=intersect(A,B);
  printf("A*B = { "); listare(C); printf("}\n");
  if (egal(A,B)) printf("A == B\n");
  else printf("A != B\n");
  distrug(A);
  distrug(B);
  distrug(C);
  return 0;
}

nod* creare(void)
{
  int x;
  nod* nou=NULL;
  scanf("%d",&x);                      /* citire intreg                    */
  if (!x) return NULL;                 /* stopare apel recursiv            */
  nou=(nod*)malloc(sizeof(nod));       /* alocare memorie pt un nod        */
  nou->inf=x;
  nou->leg=creare();                   /* apel recursiv			   */
  return nou;
}

void distrug(p)
nod* p;
{
  if (!p) return;                      /* stopare apel recursiv		   */
  distrug(p->leg);                     /* apel recursiv			   */
  free(p);                             /* eliberare memorie		   */
}

void listare(p)
nod* p;
{
  if (!p) return;                      /* stopare apel recursiv            */
  printf("%d ",p->inf);
  listare(p->leg);                     /* apel recursiv                    */
}

int egal(p, q)
nod* p;
nod* q;
{
  if (!p && !q) return 1;              /* stopare apel recursiv            */
  if (!p &&  q) return 0;              /* stopare apel recursiv            */
  if ( p && !q) return 0;              /* stopare apel recursiv            */
  return p->inf==q->inf &&             /* aici sigur p!=NULL si q!=NULL    */
	 egal(p->leg,q->leg);	       /* apel recursiv                    */
}

int exista(x, p)
int  x;
nod* p;
{
  if (!p) return 0;                    /* stopare apel recursiv            */
  return p->inf==x ||
	 exista(x,p->leg);	       /* apel recursiv                    */
}

nod* intersect(p, q)
nod* p;
nod* q;
{
  nod* nou=NULL;
  if (!p || !q) return NULL;          /* stopare apel recursiv             */
  if (exista(p->inf,q)){              /* primul element din p este si in q */
    nou=(nod*)malloc(sizeof(nod));
    nou->inf=p->inf;
    nou->leg=intersect(p->leg,q);     /* apel recursiv                     */
    return nou;
  }
  return intersect(p->leg,q);
}

/******************************** EXEMPLE ***********************************

(1) intrare: 1 2 3 0
             1 3 0
     iesire: A*B = { 1 3 }
             A != B

  DETALIEREA EXECUTIEI:

  In explicatia de mai jos am folosit in mod curent expresiile:
  "primul nod al listei..." si "restul listei..." incercand sa fac o analogie
  cu CAR si CDR din limbajul LISP. Am considerat ca este mai important sa
  pun accentul in explicatie pe modul recursiv de abordare a problemei si am
  evitat expresii de genul "...se aloca memorie pentru un nod cu malloc()..."
  sau "...se tipareste... cu printf()..." sau "p==NULL" deoarece consider ca
  acestea sunt detalii de implementare.

  apel creare()
    citeste 1, diferit de 0
    primul nod al listei este 1
    apel creare()
      citeste 2, diferit de 0
      primul nod al listei este 2
      apel creare()
        citeste 3, diferit de 0
        primul nod al listei este 3
        apel creare()
          citeste 0
        intoarce lista ()
        restul listei este lista ()
      intoarce lista (3)
      restul listei este (3)
    intoarce lista (2 3)
    restul listei este (2 3)
  intoarce lista (1 2 3)

  apel creare()
    citeste 1, diferit de 0
    primul nod al listei este 1
    apel creare()
      citeste 3, diferit de 0
      primul nod al listei este 3
      apel creare()
        citeste 0
      intoarce lista ()
      restul listei este lista ()
    intoarce lista (3)
    restul listei este (3)
  intoarce lista (1 3)

  apel intersect((1 2 3), (1 3))
    nici (1 2 3) si nici (1 3) nu sunt vide
    apel exista(1, (1 3)) in intersect()
      (1 3) nu este vida
      1 este egal cu primul nod al listei (1 3) adica cu 1
    intoarce 1 (adevarat)
    primul nod al intersectiei este 1
    apel intersect((2 3), (1 3))
      nici (2 3) si nici (1 3) nu sunt vide
      apel exista(2, (1 3))
        (1 3) nu este vida
        2 nu este egal cu 1
        apel exista(2, (3))
          (3) nu este vida
          2 nu este egal cu 3
            apel exista(2, ())
              () este vida
            intoarce 0 (fals)
          intoarce 0 (fals)
        intoarce 0 (fals)
      intoarce 0 (fals)
      apel intersect((3), (1 3))
        nici (3) si nici (1 3) nu sunt vide
        apel exista(3, (1 3))
          (1 3) nu este vida
          1 nu este egal cu 3
          apel exista(3, (3))
            (3) nu este vida
            3 este egal cu 3
          intoarce 1 (adevarat)
        intoarce 1 (adevarat)
        primul nod al intersectiei este 3
        apel intersect((), (1 3))
          primul parametru este lista vida
        intoarce lista ()
        restul intersectiei este ()
      intoarce lista (3)
      restul intersectiei este (3)
    intoarce lista (3)
    restul intersctiei este (3)
  intoarce lista (1 3)

  apel egal((1 2 3), (1 3))
    nici (1 2 3) si nici (1 3) nu sunt vide
    primul nod al listei (1 2 3) este egal cu primul nod al listei (1 3)
    apel egal ((2 3), (3))
      nici (2 3) si nici (3) nu sunt vide
      primul nod al listei (2 3) este diferit de primul nod al listei (3)
    intoarce 0 (fals)
  intoarce 0 (fals)

  apel distrug((1 2 3))
    (1 2 3) nu este vida
    apel distrug((2 3))
      (2 3) nu este vida
      apel distrug((3))
        (3) nu este vida
        apel distrug(())
          () este vida
        revenire
        eliberez 3
      revenire
      eliberez 2
    revenire
    eliberez 1
  revenire

  apel distrug((1 3))
    (1 3) nu este vida
    apel distrug((3))
      (3) nu este vida
      apel distrug(())
        () este vida
      revenire
      eliberez 3
    revenire
    eliberez 1
  revenire

  apel distrug((1 3))
    (1 3) nu este vida
    apel distrug((3))
      (3) nu este vida
      apel distrug(())
        () este vida
      revenire
      eliberez 3
    revenire
    eliberez 1
  revenire

(2) intrare: 1 2 0
             1 2 0
     iesire: A*B = { 1 2 }
             A == B

(3) intrare: 0
             0
     iesire: A*B = { }
             A == B

(4) intrare: 1 2 3 0
             0
     iesire: A*B = { }
             A != B
****************************************************************************/

#include "Lista.h"

/*
PB.1.a. Determina ultimul element al unei liste
     b. Sa se intoarca lista fara ultimul element
*/

int ultim_elem( PLista &L )
{
	if( L->leg == 0 ) return L->inf ; //dc e pe ultimul elem a listeiii
	else
	{
		int elem = ultim_elem( L->leg );
		return elem;
	};
};

PLista L_inv_fara_ultim_el( PLista &L )
{
	if( L->leg == 0 ) return 0; //dc sunt pe ultimul nod at. il eliminam
	else
	{
		PLista Laux =new lista;
		Laux = L_inv( L->leg );
		return adauga_elem_sfarsit( L->inf , Laux ); 

	};
};
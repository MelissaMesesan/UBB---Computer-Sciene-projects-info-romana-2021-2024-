#include "Lista.h"

/*
PB.11.a. Sa se testeze incluziunea  a doua multimi (liste)
      b. Sa se elimine toate aparitiile unui element intr-o lista
*/
int incluziune_mult( PLista &L1, PLista &L2 )
{
	if( !L1 ) return 1; //multimea vida e inclusa in orice mult
	else
	{
		if( L1 && !L2 ) return 0; //mult vida nu are submultimi
		else
		{
			if( e_apartine_lista( L1->inf, L2 ) && incluziune_mult( L1->leg, L2 ) )
				return 1;
			else 
				return 0;
		};
	};
};

void elim_aparitii_elem( int elem, PLista &L )
{
	if( L != 0 )
	{
		if( elem == L->inf )
		{
//			PLista Laux = new lista;
//			Laux = L;
//			PLista Laux1 = Laux->leg;
			PLista Laux = L->leg;
			delete( L );
			L = Laux;
//			Laux = Laux1;
//			return Laux;
		}
		else
			elim_aparitii_elem( elem, L->leg );
	};
};
			

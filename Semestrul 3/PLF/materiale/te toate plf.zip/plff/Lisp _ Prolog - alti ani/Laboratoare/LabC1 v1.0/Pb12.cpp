#include "Lista.h"

/*
PB.12.a. Sa se substituie toate aparitiile unui element dintr-o lista cu o alta
            lista
      b. Sa se determine elementul de pe pozitia n a unei liste
*/

PLista substit_elem_cu_lista( int elem, PLista &L1, PLista &L2 )
{
	if( !L1 || !L2 ) return 0;
	else
	{
//		PLista rez = new lista;
		if( L1->inf == elem )
		{   
			PLista Lrez = L1->leg;
			L1->leg = L2; concatenare_liste( L1, Lrez ); 
//			delete( L1 );
//			concatenare_liste( L2, L1->leg ); delete( L1 );
//			listare_lista( L1);cout <<"\n";
//			concatenare_liste( L2, Lrez );//concatenarea e distructiva!Modifica prima lista!!!
//			cout <<"Dupa concat "; listare_lista( L2 ); cout << "\n";
//			concatenare_liste( L1, L2 );
//			cout << "Dupa ultima concat: "; listare_lista( L1 ); cout << "\n";

			substit_elem_cu_lista( elem, L1->leg, L2 );
			return L1;
		}
		else
			return substit_elem_cu_lista( elem, L1->leg, L2 );
	};
};

int elem_poz_n( int indice, int pozitie, PLista &L )
{
	if( !L || indice >= pozitie ) return 0;
	else
	{
		if( indice == pozitie - 1 ) return L->inf;
		else
			return elem_poz_n( indice + 1, pozitie, L->leg );
	};
};

#include "Lista.h"

/*
PB.9.a. Sa se testeze egalitatea a doua liste
     b. Sa se determine intersectia a doua multimi(liste)
*/

int egalitate_liste( PLista &L1, PLista &L2 )
{
	if( !L1 && !L2 ) return 1;
	else
	{
		if( e_apartine_lista( L1->inf, L2 ) && egalitate_liste( L1->leg, L2->leg ) )
			if( e_apartine_lista( L2->inf, L1 ) && egalitate_liste( L2->leg, L1->leg ) ) return 1;
	};
	return 0;
};

PLista intersectie_mult( PLista &L1, PLista &L2 )
{
	if( egalitate_liste( L1, L2 ) || !L2 ) return L1; //L1 = L2 sau L2 e mult. vida, intersectia e L1
	else
	{
		if( L1 ) return 0; //dc. mult. L1 e vida, intersectia e vida
		else
		{
			if( e_apartine_lista( L1->inf, L2 ) )
			{
				PLista Lrez = new lista;
				Lrez = L1;
				Lrez->leg = intersectie_mult( L1->leg, L2 );
				return Lrez;
			}
			else
				return intersectie_mult( L1->leg, L2 );
		};
	};
};

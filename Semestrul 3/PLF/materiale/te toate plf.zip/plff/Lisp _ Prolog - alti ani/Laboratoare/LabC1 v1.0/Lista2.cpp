// definire fctiilor de creare, listare si eliminare a unei liste

#include "Lista.h"

//creaza o lista, folosind elem sirului
PLista creare_lista( int n, int sir[], int indice)
{
	if ( indice > n - 1 ) return NULL; //val. de la adresa &L
    else
	{
		PLista L=new lista;
        L->inf = sir[indice];
		L->leg = creare_lista( n, sir, indice+1);
        return L;
	};
};

void listare_lista( PLista &L )
{
	if ( L != 0 ) 
	{	
		cout << L->inf << " ";
		listare_lista( L->leg );
	};
};

void eliminare_lista( PLista &L )
{
	if( L != 0) 
		{	
			eliminare_lista( L->leg );
			delete( L ); 
		};
};

int main( )
{
//	cout << "\nDati numarul de elemente a listei: ";
//	int n;
//	cin >> n;
//	int sir[n];
//	for( int i=0; i<n; i++ ) cin >> sir[i];
	int n = 4;
    int sir[] = { 1, 2, 3, 4 };

	PLista pL = creare_lista( n, sir, 0);
    
	cout << "\nLista initiala este: ";
	listare_lista( pL );
	
	cout << "\nUltimul element a listei: ";
	int elem = ultim_elem( pL );
	cout << elem;

	cout << "\nLista inv. fara ultimul elem este: ";
	PLista pLrez = L_inv_fara_ultim_el( pL );
	listare_lista( pLrez );
	eliminare_lista( pLrez );

	cout << "\nAdaugarea unui elem la sfr. listei: ";
	pL = adauga_elem_sfarsit( 5, pL ); 
	listare_lista( pL );

	cout << "\nLungimea listei : " << lung_lista( pL );

	cout << "\nSuma elementelor listei : " << suma_elem( pL );

	cout << "\nProdusul elementelor listei: " << produs_elem( pL );



	eliminare_lista( pL);

	return 0;
}

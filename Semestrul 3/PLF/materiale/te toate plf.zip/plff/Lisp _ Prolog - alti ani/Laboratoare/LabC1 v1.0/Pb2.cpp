#include "Lista.h"

/*
PB.2.a. Sa se adauge un element la sfarsitul listei
     b. Sa se determine lungimea unei liste
*/

PLista adauga_elem_sfarsit( int e, PLista &L )
{
	if( L == 0 ) 
	{
		PLista Lultim=new lista;
		Lultim->inf = e;
		Lultim->leg = 0;

		return Lultim;
	}
	else
	{
		L->leg = adauga_elem_sfarsit( e, L->leg );
		return L;
	};
};

int lung_lista( PLista &L )
{
	if( L != 0 )
	{
		int lungime = 1 + lung_lista( L->leg );
		return lungime;
	};
	return 0;
};

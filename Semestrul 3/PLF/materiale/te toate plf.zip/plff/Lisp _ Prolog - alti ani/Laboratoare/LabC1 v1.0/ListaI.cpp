// definire fctiilor de creare, listare si eliminare a unei liste

#include "Lista.h"
#include "Proceduri.h"

//creaza o lista, folosind elem sirului
PLista creare_lista( int n, int sir[], int indice)
{
	if ( indice > n - 1 ) return NULL; //val. de la adresa &L
    else
	{
		PLista L=new lista;
        L->inf = sir[indice];
		L->leg = creare_lista( n, sir, indice+1);
        return L;
	};
};

void listare_lista( PLista &L )
{
	if ( L != 0 ) 
	{	
		cout << L->inf << " ";
		listare_lista( L->leg );
	};
};

void eliminare_lista( PLista &L )
{
	if( L != 0) 
		{	
			eliminare_lista( L->leg );
			delete( L ); 
		};
};

int main( )
{
//	cout << "\nDati numarul de elemente a listei: ";
//	int n;
//	cin >> n;
//	int sir[n];
//	for( int i=0; i<n; i++ ) cin >> sir[i];
	int n = 4;
    int sir[] = { 1, 2, 3, 4 };

	PLista pL = creare_lista( n, sir, 0);
    
	cout << "\nLista initiala este: ";
	listare_lista( pL );
	
	cout << "\nUltimul element a listei: ";
	int elem = ultim_elem( pL );
	cout << elem;

	cout << "\nLista inv. fara ultimul elem este: ";
	PLista pLrez = L_inv_fara_ultim_el( pL );
	listare_lista( pLrez );
	eliminare_lista( pLrez );

	cout << "\nAdaugarea unui elem la sfr. listei: ";
	pL = adauga_elem_sfarsit( 5, pL ); 
	listare_lista( pL );

	cout << "\nLungimea listei : " << lung_lista( pL );

	cout << "\nSuma elementelor listei : " << suma_elem( pL );

	cout << "\nProdusul elementelor listei: " << produs_elem( pL );

	cout << "\nLista inversata este: ";
	pLrez = L_inv( pL );
	listare_lista( pLrez );
	eliminare_lista( pLrez );

	cout << "\nElementul maxim al listei este: " << elem_max( pL );

	cout << "\nElementul 5 apartine listei: " << e_apartine_lista( 5, pL );

	int n1 = 4;
	int sir1[] = { 6, 7, 8, 9 };
	PLista pL1 = creare_lista( n1, sir1, 0 );
	pLrez = concatenare_liste( pL, pL1 );
	cout << "\nA doua lista este: "; listare_lista( pL1 );
    cout << "\nConcatenarea celor 2 liste e lista: "; listare_lista( pLrez );

	cout << "\nLista e: "; listare_lista( pL);
	cout << "\nLista e multime: " << lista_e_multime( pL );

	cout << "\nNumarul de elemente distincte: " << nr_elem_distincte( pL );

	int n2 = 9;
	int sir2[] = { 1, 2, 3, 3, 4, 5, 2, 6, 1 };
	PLista pL2 = creare_lista( n2, sir2, 0 );
	cout << " \nA 3-a lista este: "; listare_lista( pL2 );
//	cout << "Lista 3, dupa eliminarea aparitiilor elem 3: ";
//	elim_aparitii_elem( 3, pL2 );
//	listare_lista( pL2 );

//	cout << "\nMultimea obt. din lista a 3-a este: ";
//	pLrez = transf_lista_in_mult( pL2 );
//	listare_lista( pL2 );

	int n3 = 4;
	int sir3[] = { 11, 12, 13, 14 };
	PLista pL3 = creare_lista( n3, sir3, 0 );
	cout << " \nA 4-a lista este: "; listare_lista( pL3 );
    cout << "\nReuniunea primei liste cu a 4-a: ";
	pLrez = reuniune_mult( pL, pL3 ); //listele raman nemodificate
	listare_lista( pLrez );

	cout << "\nEgalitatea listei 1 cu ea insasi: " << egalitate_liste( pL, pL );
	cout << "\nEgalitatea listei 1 cu lista 3: " << egalitate_liste( pL, pL2 );

	cout << "\nIntersectia a doua mult este: ";
	pLrez = intersectie_mult( pL3, pL3 );
	if( !pLrez ) cout << " 0 (Lista e vida!! )";
	else
	{
		listare_lista( pLrez );
	};

	cout << "\nSubstituind al 5-lea elem din lista 1 cu 10, ob: \n";
	pLrez = substit_elem( 5, 0, 10, pL );
	listare_lista( pLrez ); //lista pL se modifica

	cout << "\nDiferenta intre 2 multimi(liste) este: \n";
	pLrez = diferenta_mult( pL1, pL3 );
	if( !pLrez ) cout << " 0 (Lista e vida!! )";
	else
	{
		listare_lista( pLrez );
	};
	cout << "\nLista pL1: "; listare_lista( pL1 );
	cout << "\nLista pL3: "; listare_lista( pL3 );

	cout << "\nIncluziunea dintre mult pL1 si pL3 este: " << incluziune_mult( pL1, pL3 );
	cout << "\nIncluziunea dintre mult pL1 si pL1 este: " << incluziune_mult( pL1, pL1 );

//	cout << "\nPrin substit.elem 3 din liste pL2 cu lista pL3, ob. lista: \n";
//	pLrez = substit_elem_cu_lista( 3, pL2, pL3 );
//	listare_lista( pLrez );
//	cout << "\nLista pL2 este: "; listare_lista( pL2 );

	cout << "\nElem de pe pozitia a 4-a din lista pL2 este: " << elem_poz_n( 0, 4, pL2 );

	citeste_date();
	int opt = Meniu();
	Pb1();


	eliminare_lista( pL);
	cout << " \n ";

	return 0;
}

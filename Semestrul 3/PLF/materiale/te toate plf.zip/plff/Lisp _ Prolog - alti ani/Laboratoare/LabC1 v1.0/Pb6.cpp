#include "Lista.h"

/*
PB.6.a. Sa se determine daca un anumit element este membru al unei liste
     b. Sa se concateneze doua liste
*/

int e_apartine_lista( int e, PLista &L )
{
	if( L != 0 )
	{
//		if ( e == L->inf ) return 1;
//		else
//			return e_apartine_lista( e, L->leg );
		return( ( e == L->inf ) || e_apartine_lista( e, L->leg ) );
	};

	return 0; //fals, dc. lista nu exista
};

PLista concatenare_liste( PLista &L1, PLista &L2 )
{
	if( L1 == 0 ) return L2; //prima lista e nula
	else
	{
		if( L1->leg == 0 ) L1->leg = L2; //dc sunt pe ultima pozitie in prima lista,concatenez
		else
			concatenare_liste( L1->leg, L2 ); //ma mut pe urm elem din prima lista

		return L1;
	};
};

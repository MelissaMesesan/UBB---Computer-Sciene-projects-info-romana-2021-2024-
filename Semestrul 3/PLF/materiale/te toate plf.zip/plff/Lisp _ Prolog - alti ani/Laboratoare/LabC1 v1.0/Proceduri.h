#ifndef Proceduri_h
#define Proceduri_h

#include "Lista.h"

int* citeste_date( );
void tipareste_date( PLista &pL );

int Meniu( );

void Pb1( );
void Pb2( );
void Pb3( );
void Pb4( );
void Pb5( );
void Pb6( );
void Pb7( );
void Pb8( );
void Pb9( );
void Pb10( );
void Pb11( );
void Pb12( );
void Pb13( );

#endif
#include "Lista.h"

/*
PB.7.a. Sa se verifice daca o lista este multime
     b. Sa se determine numarul elementelor distincte dintr-o lista
*/

int lista_e_multime( PLista &L )
{
	if( L == 0 ) return 1; //lista vida e multimea vida
	return( lista_e_multime( L->leg ) && !e_apartine_lista( L->inf, L->leg ) );
};

int nr_elem_distincte( PLista &L )
{
	if( L != 0)
	{
		if( !e_apartine_lista( L->inf, L->leg ) ) 
		{
			int sum = 1 + nr_elem_distincte( L->leg );
			return sum;
		}
		else
		{
			int sum = 0 + nr_elem_distincte( L->leg );
			return sum;
		}; 
	};

	return 0;
};

#include "Lista.h"

void tipareste_date( PLista &pL )
{
	if( !pL ) cout << " 0 (Lista e vida!! )";
	else
	{
		listare_lista( pL );
		eliminare_lista( pL );
	};
};


int* citeste_date( )  //sirul citit il pune in memoria heap 
{
	cout << "\nDati lungimea listei: ";
	int n;
	cin >> n;
	cout << "\nDati sirul: "; //int sir[] = { 1, 2, 3, 4 };
	int* sir;
	sir = ( int* )malloc( n * sizeof( int) ); 
//	cout << sizeof sir ;/// sizeof( int ) -1;
	for( int i = 0; i < n; i++ ) cin >> sir[i];i = 0;
	for( i = 0; i < n; i++ ) cout << sir[i]; i = 0;
	return sir;

//	PLista pL = creare_lista( n, sir, 0 );
//	tipareste_date( pL );
//	return pL;
};


int Meniu( )
{
	cout << "\n*****MENIU PRINCIPAL*****";
	cout << "\n    1.Problema  1...";
	cout << "\n    2.Problema  2...";
	cout << "\n    3.Problema  3...";
	cout << "\n    4.Problema  4...";
	cout << "\n    5.Problema  5...";
	cout << "\n    6.Problema  6...";
	cout << "\n    7.Problema  7...";
	cout << "\n    8.Problema  8...";
	cout << "\n    9.Problema  9...";
	cout << "\n   10.Problema 10...";
	cout << "\n   11.Problema 11...";
	cout << "\n   12.Problema 12...";
	cout << "\n   13.Problema 13...";
	cout << "\n   Iesire program...";

	cout << "\nAlegeti numarul problemei: ";
	int opt;
	cin >> opt;
	
	return opt;
};

void Pb1( )
{

	int* sir = citeste_date( );
	PLista pL = creare_lista( sizeof sir, sir, 0);

	cout << "\nUltimul element a listei: " << ultim_elem( pL );

	cout << "\nLista inv. fara ultimul elem este: ";
	
	PLista pLrez = L_inv_fara_ultim_el( pL );
	tipareste_date( pLrez );

	eliminare_lista( pL );
	free( sir );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb2( )
{
	int* sir = citeste_date( );
//	for( int i = 0; i<sizeof sir ; i++) cout << sir[i];
	PLista pL = creare_lista( sizeof sir, sir, 0 );
	tipareste_date( pL );//free( sir );
	
	cout << "\nAdaugarea unui elem la sfr. listei: ";
	PLista pLrez = adauga_elem_sfarsit( 5, pL ); 
	tipareste_date( pLrez );

	cout << "\nLungimea listei : " << lung_lista( pL );

	eliminare_lista( pL );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );
};

void Pb3( )
{
	int* sir = citeste_date( );
	PLista pL = creare_lista( sizeof sir, sir, 0 );

	cout << "\nCerinta: a)Sa se det. dc lista are un nr. par de elem  nu a fost facuta!";
	cout << "\nSuma elementelor listei : " << suma_elem( pL );
	
	eliminare_lista( pL );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );
};

void Pb4( )
{
	int* sir = citeste_date( );
	PLista pL = creare_lista( sizeof sir, sir, 0 );

	cout << "\nCerinta a) nu a fost facuta!";
	cout << "\nProdusul elementelor listei: " << produs_elem( pL );

	eliminare_lista( pL );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb5( )
{
	int* sir = citeste_date( );
	PLista pL = creare_lista( sizeof sir, sir, 0 );

	cout << "\nLista inversata este: ";
	PLista pLrez = L_inv( pL );
	tipareste_date( pLrez );
	

	cout << "\nElementul maxim al listei este: " << elem_max( pL );

	eliminare_lista( pL );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb6( )
{
	int* sir1 = citeste_date( );
	PLista pL1 = creare_lista( sizeof sir1, sir1, 0 );
	
	int nr;
	cout << "\nDati elementul care trebuie cautat in lista: ";
	cin >> nr;
	cout << "\nElementul" << nr << " apartine listei: " << e_apartine_lista( 5, pL1 );

	cout << "\nLista a 2-a pentru concatenare: ";
	int* sir2 = citeste_date( );
	PLista pL2 = creare_lista( sizeof sir2, sir2, 0 );
	PLista pLrez = concatenare_liste( pL1, pL2 );
	cout << "\nConcatenarea celor 2 liste e lista: "; 
	tipareste_date( pLrez );

	eliminare_lista( pL1 );
	eliminare_lista( pL2 );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb7( )
{
	int* sir = citeste_date( );
	PLista pL = creare_lista( sizeof sir, sir, 0 );

	cout << "\nLista e multime: " << lista_e_multime( pL );

	cout << "\nNumarul de elemente distincte: " << nr_elem_distincte( pL );

	eliminare_lista( pL );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb8( )
{
	int* sir1 = citeste_date( );
	PLista pL1 = creare_lista( sizeof sir1, sir1, 0 );

	cout << "\nMultimea obtinuta din lista data este: ";
	PLista pLrez1 = transf_lista_in_mult( pL1 );
	tipareste_date( pLrez1 );
	
	cout << "\nMultimea a 2-a pt. reuniune: ";
	int* sir2 = citeste_date( );
	PLista pL2 = creare_lista( sizeof sir2, sir2, 0 );
	cout << "\nReuniunea celor 2 multimi este: ";
	PLista pLrez2 = reuniune_mult( pL1, pL2 );
	tipareste_date( pLrez2 );

	eliminare_lista( pL1 );
	eliminare_lista( pL2 );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb9( )
{
	cout << "\nPrima lista: ";
	int* sir1 = citeste_date( );
	PLista pL1 = creare_lista( sizeof sir1, sir1, 0 );
	
	cout << "\nA 2-a lista: ";
	int* sir2 = citeste_date( );
	PLista pL2 = creare_lista( sizeof sir2, sir2, 0 );

	cout << "\nEgalitatea listei 1 cu ea insasi: " << egalitate_liste( pL1, pL1 );
	cout << "\nEgalitatea primei liste  cu a 2-a lista: " << egalitate_liste( pL1, pL2 );

	cout << "\nIntersectia celor doua mult este: ";
	PLista pLrez = intersectie_mult( pL1, pL2 );
	tipareste_date( pLrez );

	eliminare_lista( pL1 );
	eliminare_lista( pL2 );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb10( )
{
	cout << "\nPrima lista: ";
	int* sir1 = citeste_date( );
	PLista pL1 = creare_lista( sizeof sir1, sir1, 0 );
	
	cout << "\nPunctul a) nu a fost rezolvat!!! ";

	cout << "\nA 2-a lista: ";
	int* sir2 = citeste_date( );
	PLista pL2 = creare_lista( sizeof sir2, sir2, 0 );
	
	cout << "\nIntersectia celor doua multimi este: ";
	PLista pLrez = intersectie_mult( pL1, pL2 );
	tipareste_date( pLrez );

	eliminare_lista( pL1 );
	eliminare_lista( pL2 );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb11( )
{
	cout << "\nPrima lista: ";
	int* sir1 = citeste_date( );
	PLista pL1 = creare_lista( sizeof sir1, sir1, 0 );
	
	cout << "\nA 2-a lista: ";
	int* sir2 = citeste_date( );
	PLista pL2 = creare_lista( sizeof sir2, sir2, 0 );

	cout << "\nPrima multime este " << incluziune_mult( pL1, pL2 ) << "in a 2-a multime ";

	int indice, elem;
	cout << "\nDati indicele elementului: "; cin >> indice;
	cout << "\nDati elementul de substitutie: "; cin >> elem;
	cout << "\nSubstituind al " << indice << "-lea elem din prima lista  cu " << elem << ", ob: \n";
	PLista pLrez = substit_elem( indice, 0, elem, pL1 );
	tipareste_date( pLrez ); //lista pL se modifica

	eliminare_lista( pL1 );
	eliminare_lista( pL2 );

	cout << "\n\nApasati orice tasta pt. a reveni la meniul anterior...";
	getch( );

};

void Pb12( )
{

};

void Pb13( )
{
};
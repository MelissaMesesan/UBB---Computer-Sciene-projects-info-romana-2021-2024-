#include "Lista.h"

/*
PB.4.a. Sa se determine numarul format prin insumarea elementelor de ordin par
           ale unei liste, din care se scad elementele de ordin impar ale listei
     b. Sa se determine produsul elementelor unei liste
*/

int numar_par_minus_impar( PLista &L )
{
	return 0;
};


int produs_elem( PLista &L )
{
	if( L != 0 )
	{
		int produs = L->inf * produs_elem( L->leg );
		return produs;
	};

	return 1;
};

#include "Lista.h"

/*
PB.8.a. Sa se transforme o lista intr-o multime
     b. Sa se determine reuniunea a doua multimi(liste)
*/

PLista transf_lista_in_mult( PLista &L )
{
	if( L == 0 ) return 0;
	else
	{ 
		elim_aparitii_elem( L->inf, L->leg );
		return transf_lista_in_mult( L->leg );
//		return L;
	};
};

PLista reuniune_mult( PLista &L1, PLista &L2 ) //consid. cele 2 liste ca fiind multimi
{
	if( L1 == 0 ) return L2;
	else
	{
		PLista Lrez = new lista;
		Lrez->inf = L1->inf;
		Lrez->leg = reuniune_mult( L1->leg, L2 );
		transf_lista_in_mult( Lrez );

		return Lrez;
	};
};

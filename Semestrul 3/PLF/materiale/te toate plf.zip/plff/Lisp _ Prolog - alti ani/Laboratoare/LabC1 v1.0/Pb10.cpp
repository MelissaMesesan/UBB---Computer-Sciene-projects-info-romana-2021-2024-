#include "Lista.h"

/*
PB.10.a. Sa se substituie al i-lea element dintr-o lista
      b. Sa se determine diferenta a doua multimi(liste)
*/

PLista substit_elem( int indice, int pozitie, int nr, PLista &L ) //indice=i, pozitia=pozitia curenta in L
{
	if( ( L == 0 ) || ( pozitie > indice - 1 ) )return 0;
	else
	{
		if( pozitie < indice - 1 ) substit_elem( indice, pozitie+1, nr, L->leg );
		else
			L->inf = nr;
	};

	return L;
};

PLista diferenta_mult( PLista &L1, PLista &L2 )
{
	if( ( L1 == 0 ) || ( egalitate_liste( L1, L2 ) ) ) return 0;
	else
	{
		if( !e_apartine_lista( L1->inf, L2 ) )
		{
			PLista Lrez = new lista;
			Lrez = L1;
			Lrez->leg = diferenta_mult(L1->leg, L2 );
		    return Lrez;
		}
		else
			return diferenta_mult( L1->leg, L2 );
	
	};
};

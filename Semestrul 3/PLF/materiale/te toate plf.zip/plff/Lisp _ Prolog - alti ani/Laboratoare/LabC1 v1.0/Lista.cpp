// definire fctiilor de creare, listare si eliminare a unei liste

#include "Lista.h"
#include "Proceduri.h"

//creaza o lista, folosind elem sirului
PLista creare_lista( int n, int sir[], int indice)
{
	if ( indice > n - 1 ) return 0; //val. de la adresa &L
    else
	{
		PLista L=new lista;
        L->inf = sir[indice];
		L->leg = creare_lista( n, sir, indice+1);
        return L;
	};
};

void listare_lista( PLista &L )
{
	if ( L != 0 ) 
	{	
		cout << L->inf << " ";
		listare_lista( L->leg );
	};
};

void eliminare_lista( PLista &L )
{
	if( L != 0) 
		{	
			eliminare_lista( L->leg );
			delete( L ); 
		};
};

int main( )
{
	int bit = 1;

	while( bit )
	{
		int opt = Meniu();
		switch( opt )
		{
			case 1:
				Pb1( );
				break;
			case 2:
				Pb2( );
				break;
			case 3:
				Pb3( );
				break;
			case 4:
				Pb4( );
				break;
			case 5:
				Pb5( );
				break;
			case 6:
				Pb6( );
				break;
			case 7:
				Pb7( );
				break;
			case 8:
				Pb8( );
				break;
			case 9:
				Pb9( );
				break;
			case 10:
				Pb10( );
				break;
			case 11:
				Pb11( );
				break;
			case 12:
				Pb12( );
				break;
			//case 13:
			//	Pb13( );
			//	break;
			default:
				bit = 0;
				break;
		}; //de la cel mai exterior switch
	};//de la cel mai exterior while

	cout << "\nIesire program....";

	return 0;
}

#ifndef _Pb8_h
#define _Pb8_h

#include "Lista.h"

/*
PB.8.a. Sa se transforme o lista intr-o multime
     b. Sa se determine reuniunea a doua multimi(liste)
*/
PLista transf_lista_in_mult( PLista &L );
PLista reuniune_mult( PLista &L1, PLista &L2 );

void Pb8( );

#endif
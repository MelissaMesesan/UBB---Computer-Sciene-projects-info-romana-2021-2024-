#ifndef _Pb6_h
#define _Pb6_h

#include "Lista.h"

/*
PB.6.a. Sa se determine daca un anumit element este membru al unei liste
     b. Sa se concateneze doua liste
*/
int e_apartine_lista( int e, PLista &L );
PLista concatenare_liste( PLista &L1, PLista &L2 );

void Pb6( );

#endif
#ifndef _Pb3_h
#define _Pb3_h

#include "Lista.h"

/*
PB.3.a. Sa se determine daca lista are numar par de elemente, fara sa se
           calculeze lungimea
     b. Sa se determine suma elementelor unei liste
*/
int nr_par_de_elem( PLista &L );
int suma_elem( PLista &L );

void Pb3( );

#endif
#include "Pb1.h"
#include "Pb2.h"
#include "Pb3.h"
#include "Pb4.h"
#include "Pb5.h"
#include "Pb6.h"
#include "Pb7.h"
#include "Pb8.h"
#include "Pb9.h"
#include "Pb10.h"

int Meniu( )
{
	cout << "\n*****MENIU PRINCIPAL*****";
	cout << "\n    1.Problema  1...";
	cout << "\n    2.Problema  2...";
	cout << "\n    3.Problema  3...";
	cout << "\n    4.Problema  4...";
	cout << "\n    5.Problema  5...";
	cout << "\n    6.Problema  6...";
	cout << "\n    7.Problema  7...";
	cout << "\n    8.Problema  8...";
	cout << "\n    9.Problema  9...";
	cout << "\n   10.Problema 10...";
	cout << "\n   11.Problema 11...";
	cout << "\n   12.Problema 12...";
	cout << "\n   13.Problema 13...";
	cout << "\n   Iesire program...";

	cout << "\nAlegeti numarul problemei: ";
	int opt;
	cin >> opt;
	
	return opt;
};

//programul principal al aplicatiei
int main( )
{
  int bit = 1;
  while( bit )
  {
	int opt = Meniu();
	switch( opt )
	{
	  case 1:
		Pb1( );
		break;
	  case 2:
		Pb2( );
		break;
	  case 3:
		Pb3( );
		break;
	  case 4:
		Pb4( );
		break;
	  case 5:
		Pb5( );
	  	break;
	  case 6:
		Pb6( );
	  	break;
	  case 7:
		Pb7( );
		break;
	  case 8:
		Pb8( );
	  	break;
	  case 9:
		Pb9( );
	  	break;
	  case 10:
		Pb10( );
		break;
/*	  case 11:
		Pb11( );
		break;
	  case 12:
	  	Pb12( );
		break;
	  case 13:
		Pb13( );
		break;
*/	  default:
		bit = 0;
		break;
	}; //de la cel mai exterior switch
  };//de la cel mai exterior while

	cout << "\nIesire program....";

	return 0;
}
 
  

#ifndef _Pb2_h
#define _Pb2_h

#include "Lista.h"

/*
PB.2.a. Sa se adauge un element la sfarsitul listei
     b. Sa se determine lungimea unei liste
*/
PLista adauga_elem_sfarsit( int e, PLista &L );
int lung_lista( PLista &L );

void Pb2( );

#endif
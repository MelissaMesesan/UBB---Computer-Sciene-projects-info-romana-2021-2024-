#ifndef _Pb11_h
#define _Pb11_h

#include "Lista.h"

/*
PB.11.a. Sa se testeze incluziunea  a doua multimi (liste)
      b. Sa se elimine toate aparitiile unui element intr-o lista
*/
int incluziune_mult( PLista &L1, PLista &L2 );
void elim_aparitii_elem( int elem, PLista &L );

void Pb11;

#endif

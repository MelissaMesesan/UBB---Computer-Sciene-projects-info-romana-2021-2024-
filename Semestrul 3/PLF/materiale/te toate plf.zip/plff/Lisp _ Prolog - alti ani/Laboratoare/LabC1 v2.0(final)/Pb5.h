#ifndef _Pb5_h
#define _Pb5_h

#include "Lista.h"

/*
PB.5.a. Sa se inverseze o lista
     b. Sa se determine elementul maxim al unei liste
*/
PLista L_inv( PLista &L );
int elem_max( PLista &L );

void Pb5( );

#endif
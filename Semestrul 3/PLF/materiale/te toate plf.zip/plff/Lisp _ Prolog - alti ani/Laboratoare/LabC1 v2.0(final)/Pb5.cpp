#include "Lista.h"

/*
PB.5.a. Sa se inverseze o lista
     b. Sa se determine elementul maxim al unei liste
*/
PLista L_inv( PLista &L )
{
	if( L == 0 ) return 0;
	else
	{
		PLista Laux =new lista;
		Laux = L_inv( L->leg );
		return adauga_elem_sfarsit( L->inf , Laux ); 
	};
};

int elem_max( PLista &L )
{
	if( L != 0 )
	{
		if( L->inf > elem_max( L->leg ) ) return L->inf ;
		else
			return elem_max( L->leg );
	};

	return 0; //lista e vida => nu are elem maxim
};

void Pb5( )
{
//declaratii de variabile  
  int sir[20], n;
  PLista pL;
//initialiarea listei
  cout << "\nDati lungimea listei: ";
  cin >> n;
  
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( int i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)
  PLista pLrez = L_inv( pL );
  cout << "\nLista inversata este: "; 
  listare_lista( pLrez );
//cerinte: b)  
  cout << "\nElem maxim al listei este: " << elem_max( pL );  
  
};

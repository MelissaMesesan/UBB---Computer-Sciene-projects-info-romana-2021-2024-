#include "Lista.h"

/*
PB.11.a. Sa se testeze incluziunea  a doua multimi (liste)
      b. Sa se elimine toate aparitiile unui element intr-o lista
*/
int incluziune_mult( PLista &L1, PLista &L2 )
{
	if( !L1 ) return 1; //multimea vida e inclusa in orice mult
	else
	{
		if( L1 && !L2 ) return 0; //mult vida nu are submultimi
		else
		{
			if( e_apartine_lista( L1->inf, L2 ) && incluziune_mult( L1->leg, L2 ) )
				return 1;
			else 
				return 0;
		};
	};
};

void elim_aparitii_elem( int elem, PLista &L )
{
	if( L != 0 )
	{
		if( elem == L->inf )
		{
//			PLista Laux = new lista;
//			Laux = L;
//			PLista Laux1 = Laux->leg;
			PLista Laux = L->leg;
			delete( L );
			L = Laux;
//			Laux = Laux1;
//			return Laux;
		}
		else
			elim_aparitii_elem( elem, L->leg );
	};
};
			
void Pb11( )
{
  int sir1[20], sir2[20];
  int n1, n2, i;
  PLista pL1, pL2;
  
  cout << "\nDati lungimile listelor: ";
  cin >> n1 >> n2;
//crearea primei liste  
  if( n1 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL1 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n1; i++ ) cin >> sir1[i];
	pL1 = creare_lista( n1, sir1, 0 );
  };
//crearea celei de-a 2-a liste
  if( n2 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL2 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n2; i++ ) cin >> sir2[i];
	pL2 = creare_lista( n2, sir2, 0 );
  };

//cerinte: a)  
  cout << "\nPrima lista este " << incluziune_mult( pL1, pL2 ) << " inclusa in a 2-a lista";
//cerinte: b)  
  int elem1, elem2;
  cout << "\nDati elementele de eliminat(un element pt. fiecare lista): ";
  elim_aparitii_elem( elem1, pL1 );
  listare_lista( pL1 );
  elim_aparitii_elem( elem2, pL2 );
  listare_lista( pL2 );


  
};

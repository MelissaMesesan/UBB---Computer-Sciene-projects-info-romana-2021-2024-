#ifndef _Pb1_h
#define _Pb1_h

#include "Lista.h"

/*
PB.1.a. Determina ultimul element al unei liste
     b. Sa se intoarca lista fara ultimul element
*/
int ultim_elem( PLista &L );
PLista L_inv_fara_ultim_el( PLista &L );

void Pb1( );

#endif
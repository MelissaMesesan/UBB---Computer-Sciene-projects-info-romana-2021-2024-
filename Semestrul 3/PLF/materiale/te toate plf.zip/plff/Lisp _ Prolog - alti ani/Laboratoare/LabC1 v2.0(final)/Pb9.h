#ifndef _Pb9_h
#define _Pb9_h

#include "Lista.h"

/*
PB.9.a. Sa se testeze egalitatea a doua liste
     b. Sa se determine intersectia a doua multimi(liste)
*/
int egalitate_liste( PLista &L1, PLista &L2 );
PLista intersectie_mult( PLista &L1, PLista &L2 );

void Pb9( );

#endif
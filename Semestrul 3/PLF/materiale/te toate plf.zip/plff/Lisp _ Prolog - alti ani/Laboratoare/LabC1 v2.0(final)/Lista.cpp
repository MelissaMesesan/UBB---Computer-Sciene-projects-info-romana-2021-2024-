// definire fctiilor de creare, listare si eliminare a unei liste

#include "Lista.h"

//creaza o lista, folosind elem sirului
PLista creare_lista( int n, int sir[], int indice)
{
	if ( ( indice > n - 1 ) || ( n == 0 ) ) return 0; //val. de la adresa &L
    else											 // n = 0 cand lista e vida
	{
		PLista L=new lista;
        L->inf = sir[indice];
		L->leg = creare_lista( n, sir, indice+1);
        return L;
	};
};

void listare_lista( PLista &L )
{
	if ( L != 0 ) 
	{	
		cout << L->inf << " ";
		listare_lista( L->leg );
	};
};

void eliminare_lista( PLista &L )
{
	if( L != 0) 
		{	
			eliminare_lista( L->leg );
			delete( L ); 
		};
};


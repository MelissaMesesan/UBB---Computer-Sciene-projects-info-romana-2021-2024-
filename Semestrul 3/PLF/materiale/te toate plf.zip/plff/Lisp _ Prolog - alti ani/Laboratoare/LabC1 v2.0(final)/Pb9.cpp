#include "Lista.h"

/*
PB.9.a. Sa se testeze egalitatea a doua liste
     b. Sa se determine intersectia a doua multimi(liste)
*/

int egalitate_liste( PLista &L1, PLista &L2 )
{
	if( !L1 && !L2 ) return 1;
	else
	{
		if( e_apartine_lista( L1->inf, L2 ) && egalitate_liste( L1->leg, L2->leg ) )
			if( e_apartine_lista( L2->inf, L1 ) && egalitate_liste( L2->leg, L1->leg ) ) return 1;
	};
	return 0;
};

PLista intersectie_mult( PLista &L1, PLista &L2 )
{
	if( egalitate_liste( L1, L2 ) || !L2 ) return L1; //L1 = L2 sau L2 e mult. vida, intersectia e L1
	else
	{
		if( L1 ) return 0; //dc. mult. L1 e vida, intersectia e vida
		else
		{
			if( e_apartine_lista( L1->inf, L2 ) )
			{
				PLista Lrez = new lista;
				Lrez = L1;
				Lrez->leg = intersectie_mult( L1->leg, L2 );
				return Lrez;
			}
			else
				return intersectie_mult( L1->leg, L2 );
		};
	};
};

void Pb9( )
{
  int sir1[20], sir2[20];
  int n1, n2, i;
  PLista pL1, pL2;
  
  cout << "\nDati lungimile listelor: ";
  cin >> n1 >> n2;
//crearea primei liste  
  if( n1 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL1 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n1; i++ ) cin >> sir1[i];
	pL1 = creare_lista( n1, sir1, 0 );
  };
//crearea celei de-a 2-a liste
  if( n2 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL2 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n2; i++ ) cin >> sir2[i];
	pL2 = creare_lista( n2, sir2, 0 );
  };

//cerinte: a)  
  cout << "\nPrima lista este " << egalitate_liste( pL1, pL2 ) << "egala cu ce-a de-a 2-a";
//cerinte: b)  
  PLista pLrez = intersectie_mult( pL1, pL2 );
  cout << "\nLista rezultata in urma intersectiei este: "; listare_lista( pLrez );
  
};


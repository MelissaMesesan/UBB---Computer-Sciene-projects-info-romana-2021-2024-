#include "Lista.h"

/*
PB.3.a. Sa se determine daca lista are numar par de elemente, fara sa se
           calculeze lungimea
     b. Sa se determine suma elementelor unei liste
*/

int nr_par_de_elem( PLista &L )
{
	return 0;
};

int suma_elem( PLista &L )
{
	if( L != 0 )
	{
		int suma = L->inf + suma_elem( L->leg );
		return suma;
	};

	return 0; 
};

void Pb3( )
{
//initializarea listei  
  int sir[20], n, i;
  PLista pL;
  cout << "\nDati lungimea listei: ";
  cin >> n;
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)
  cout << "\nPunctul a) nu a fost rezolvat! ";
//cerinte: b)  
  cout << "\nLista are " << suma_elem( pL ) << " elemente";
  	
};
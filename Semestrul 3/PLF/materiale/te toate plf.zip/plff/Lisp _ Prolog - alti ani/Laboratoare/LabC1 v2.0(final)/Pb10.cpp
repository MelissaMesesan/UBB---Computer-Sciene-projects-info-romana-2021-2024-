#include "Lista.h"

/*
PB.10.a. Sa se substituie al i-lea element dintr-o lista
      b. Sa se determine diferenta a doua multimi(liste)
*/

PLista substit_elem( int indice, int pozitie, int nr, PLista &L ) //indice=i, pozitia=pozitia curenta in L
{
	if( ( L == 0 ) || ( pozitie > indice - 1 ) )return 0;
	else
	{
		if( pozitie < indice - 1 ) substit_elem( indice, pozitie+1, nr, L->leg );
		else
			L->inf = nr;
	};

	return L;
};

PLista diferenta_mult( PLista &L1, PLista &L2 )
{
	if( ( L1 == 0 ) || ( egalitate_liste( L1, L2 ) ) ) return 0;
	else
	{
		if( !e_apartine_lista( L1->inf, L2 ) )
		{
			PLista Lrez = new lista;
			Lrez = L1;
			Lrez->leg = diferenta_mult(L1->leg, L2 );
		    return Lrez;
		}
		else
			return diferenta_mult( L1->leg, L2 );
	
	};
};

void Pb10( )
{
  int sir1[20], sir2[20];
  int n1, n2, i;
  PLista pL1, pL2;

//crearea primei liste
  cout << "\nDati lungimile listelor: ";
  cin >> n1 >> n2;
  if( n1 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL1 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n1; i++ ) cin >> sir1[i];
	pL1 = creare_lista( n1, sir1, 0 );
  };
//crearea celei de-a 2-a liste
  if( n2 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL2 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n2; i++ ) cin >> sir2[i];
	pL2 = creare_lista( n2, sir2, 0 );
  };

//cerinte: a)  
  int elem1, elem2;
  int indice1, indice2;
  cout << "\nDati indicele elem de substituit in liste( un indice pt. fiecare lista): ";
  cin >> indice1 >> indice2;
  cout << "\nDati numerele substit pt. liste liste( un nr. pt. fiecare lista): ";
  cin >> elem1 >> elem2;
  cout << "\nPrima lista, dupa substituire, este: ";
  PLista pLrez1 = substit_elem( indice1, 0, elem1, pL1 ); 
  cout << "\nA 2-a lista, dupa substituire, este: ";
  PLista pLrez2 = substit_elem( indice2, 0, elem2, pL2 ); 
//cerinte: b)  
  PLista pLrez = diferenta_mult( pL1, pL2 );
  cout << "\nLista rezultata in urma diferentei este: "; listare_lista( pLrez );
  
};
#include "Lista.h"

/*
PB.2.a. Sa se adauge un element la sfarsitul listei
     b. Sa se determine lungimea unei liste
*/

PLista adauga_elem_sfarsit( int e, PLista &L )
{
	if( L == 0 ) 
	{
		PLista Lultim=new lista;
		Lultim->inf = e;
		Lultim->leg = 0;

		return Lultim;
	}
	else
	{
		L->leg = adauga_elem_sfarsit( e, L->leg );
		return L;
	};
};

int lung_lista( PLista &L )
{
	if( L != 0 )
	{
		int lungime = 1 + lung_lista( L->leg );
		return lungime;
	};
	return 0;
};

void Pb2( )
{
  int sir[20], n;
  PLista pL;
  cout << "\nDati lungimea listei: ";
  cin >> n;
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( int i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)  
  int ultim;
  cout << "\nElementul de adaugat la lista: "; cin >> ultim;
  PLista pLrez = adauga_elem_sfarsit( ultim, pL );
  cout << "\nLista va fi: "; listare_lista( pLrez );
//cerinte: b)
  cout << "\nLungimea listei este: " << lung_lista( pL );
};
	
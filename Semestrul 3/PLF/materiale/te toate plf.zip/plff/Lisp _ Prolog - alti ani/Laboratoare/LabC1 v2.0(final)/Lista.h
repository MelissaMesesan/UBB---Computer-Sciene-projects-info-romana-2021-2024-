/*
C1:	Programare recursiva cu liste liniare in limbajele C si Pascal
	--------------------------------------------------------------
	Sa se scrie programe in C/Pascal ce vor utiliza fctii sau proceduri recursive, cu cerintele urm.
    !!OBS!!!: Crearea, listarea si eliminarea listelor se va face tot recursiv.!!!
*/
#ifndef _Lista_h
#define _Lista_h

#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

struct lista{
	int inf;
	struct lista *leg; //pointer la lista(elem urm):contine adresa 
};
typedef lista* PLista;

PLista creare_lista( int n, int sir[], int indice ); //adresa lui L
void listare_lista( PLista &L ); //adresa lui L
void eliminare_lista( PLista &L );
/*
PB.1.a. Determina ultimul element al unei liste
     b. Sa se intoarca lista fara ultimul element
*/
int ultim_elem( PLista &L );
PLista L_inv_fara_ultim_el( PLista &L );
void Pb1( );

/*
PB.2.a. Sa se adauge un element la sfarsitul listei
     b. Sa se determine lungimea unei liste
*/
PLista adauga_elem_sfarsit( int e, PLista &L );
int lung_lista( PLista &L );
void Pb2( );

/*
PB.3.a. Sa se determine daca lista are numar par de elemente, fara sa se
           calculeze lungimea
     b. Sa se determine suma elementelor unei liste
*/
int nr_par_de_elem( PLista &L );
int suma_elem( PLista &L );
void Pb3( );

/*
PB.4.a. Sa se determine numarul format prin insumarea elementelor de ordin par
           ale unei liste, din care se scad elementele de ordin impar ale listei
     b. Sa se determine produsul elementelor unei liste
*/
int numar_par_minus_impar( PLista &L );
int produs_elem( PLista &L );
void Pb4( );

/*
PB.5.a. Sa se inverseze o lista
     b. Sa se determine elementul maxim al unei liste
*/
PLista L_inv( PLista &L );
int elem_max( PLista &L );
void Pb5( );

/*
PB.6.a. Sa se determine daca un anumit element este membru al unei liste
     b. Sa se concateneze doua liste
*/
int e_apartine_lista( int e, PLista &L );
PLista concatenare_liste( PLista &L1, PLista &L2 );
void Pb6( );

/*
PB.7.a. Sa se verifice daca o lista este multime
     b. Sa se determine numarul elementelor distincte dintr-o lista
*/
int lista_e_multime( PLista &L );
int nr_elem_distincte( PLista &L );
void Pb7( );

/*
PB.8.a. Sa se transforme o lista intr-o multime
     b. Sa se determine reuniunea a doua multimi(liste)
*/
PLista transf_lista_in_mult( PLista &L );
PLista reuniune_mult( PLista &L1, PLista &L2 );
void Pb8( );

/*
PB.9.a. Sa se testeze egalitatea a doua liste
     b. Sa se determine intersectia a doua multimi(liste)
*/
int egalitate_liste( PLista &L1, PLista &L2 );
PLista intersectie_mult( PLista &L1, PLista &L2 );
void Pb9( );

/*
PB.10.a. Sa se substituie al i-lea element dintr-o lista
      b. Sa se determine diferenta a doua multimi(liste)
*/
PLista substit_elem( int indice, int pozitie, int nr, PLista &L );
PLista diferenta_mult( PLista &L1, PLista &L2 );
void Pb10( );

/*
PB.11.a. Sa se testeze incluziunea  a doua multimi (liste)
      b. Sa se elimine toate aparitiile unui element intr-o lista
*/
int incluziune_mult( PLista &L1, PLista &L2 );
void elim_aparitii_elem( int elem, PLista &L );
void Pb11( );

/*
PB.12.a. Sa se substituie toate aparitiile unui element dintr-o lista cu o alta
            lista
      b. Sa se determine elementul de pe pozitia n a unei liste

PLista substit_elem_cu_lista( int elem, PLista &L1, PLista &L2 );
int elem_poz_n( int indice, int pozitie, PLista &L );


PB.13.a. Sa se determine cel mai mare divizor comun al elementelor unei liste
      b. Sa se intercaleze un element pe pozitia n a unei liste

int cmmdc_elem( PLista &L );
PLista intercalare_e_poz_n( int indice, int e, PLista &L );
*/

#endif
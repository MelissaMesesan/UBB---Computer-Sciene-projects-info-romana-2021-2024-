#ifndef _Pb10_h
#define Pb10_h

#include "Lista.h"

/*
PB.10.a. Sa se substituie al i-lea element dintr-o lista
      b. Sa se determine diferenta a doua multimi(liste)
*/
PLista substit_elem( int indice, int pozitie, int nr, PLista &L );
PLista diferenta_mult( PLista &L1, PLista &L2 );

void Pb10( );

#endif
#include "Lista.h"

/*
PB.1.a. Determina ultimul element al unei liste
     b. Sa se intoarca lista fara ultimul element
*/

int ultim_elem( PLista &L )
{
	if( L == 0 ) return 0;
	if( L->leg == 0 ) return L->inf ; //dc e pe ultimul elem a listeiii
	else
	{
		int elem = ultim_elem( L->leg );
		return elem;
	};
};

PLista L_inv_fara_ultim_el( PLista &L )
{
	if ( L == 0 ) return 0;
	if( L->leg == 0 ) return( L = 0 ); //dc sunt pe ultimul nod at. il eliminam
	else
	{
		L_inv_fara_ultim_el( L->leg ); // altfel merg mai departe 
		return L;
	};
};

void Pb1( )
{
//initializare lista  
  int sir[20], n, i;
  PLista pL;
  cout << "\nDati lungimea listei: ";
  cin >> n;
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)
  int ultim = ultim_elem( pL );  
  cout << "\nUltimul elem al listei este: " << ultim;
//cerinte: b)  
  PLista pLrez = L_inv_fara_ultim_el( pL );
  cout << "\nLista fara ultimul elem este: "; listare_lista( pLrez );

};
	
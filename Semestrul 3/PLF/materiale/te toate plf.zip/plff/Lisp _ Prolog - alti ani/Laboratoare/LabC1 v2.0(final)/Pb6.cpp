#include "Lista.h"

/*
PB.6.a. Sa se determine daca un anumit element este membru al unei liste
     b. Sa se concateneze doua liste
*/

int e_apartine_lista( int e, PLista &L )
{
	if( L != 0 )
	{
//		if ( e == L->inf ) return 1;
//		else
//			return e_apartine_lista( e, L->leg );
		return( ( e == L->inf ) || e_apartine_lista( e, L->leg ) );
	};

	return 0; //fals, dc. lista nu exista
};

PLista concatenare_liste( PLista &L1, PLista &L2 )
{
	if( L1 == 0 ) return L2; //prima lista e nula
	else
	{
		if( L1->leg == 0 ) L1->leg = L2; //dc sunt pe ultima pozitie in prima lista,concatenez
		else
			concatenare_liste( L1->leg, L2 ); //ma mut pe urm elem din prima lista

		return L1;
	};
};

void Pb6( )
{
//declaratii de variabile
  int sir1[20], sir2[20];
  int n1, n2, i;
  PLista pL1, pL2;
  
  cout << "\nDati lungimile listelor: ";
  cin >> n1 >> n2;
//crearea primei liste  
  if( n1 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL1 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n1; i++ ) cin >> sir1[i];
	pL1 = creare_lista( n1, sir1, 0 );
  };
//crearea celei de-a 2-a liste
  if( n2 == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL2 = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n2; i++ ) cin >> sir2[i];
	pL2 = creare_lista( n2, sir2, 0 );
  };

//cerinte: a)  
  int elem1, elem2;
  cout << "\nDati elementele de cautat in lista( un nr. pt. fiecare lista): ";
  cin >> elem1 >> elem2;
  cout << "\nElem " << elem1 << " apartine primei liste: " << e_apartine_lista( elem1, pL1 );
  cout << "\nElem " << elem2 << " apartine listei 2: " << e_apartine_lista( elem2, pL2 );
//cerinte: b)  
  PLista pLrez = concatenare_liste( pL1, pL2 );
  cout << "\nLista rezultata este: "; listare_lista( pLrez );
  
};
	


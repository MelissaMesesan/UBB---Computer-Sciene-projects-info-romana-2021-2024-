#include "Lista.h"

/*
PB.7.a. Sa se verifice daca o lista este multime
     b. Sa se determine numarul elementelor distincte dintr-o lista
*/

int lista_e_multime( PLista &L )
{
	if( L == 0 ) return 1; //lista vida e multimea vida
	return( lista_e_multime( L->leg ) && !e_apartine_lista( L->inf, L->leg ) );
};

int nr_elem_distincte( PLista &L )
{
	if( L != 0)
	{
		if( !e_apartine_lista( L->inf, L->leg ) ) 
		{
			int sum = 1 + nr_elem_distincte( L->leg );
			return sum;
		}
		else
		{
			int sum = 0 + nr_elem_distincte( L->leg );
			return sum;
		}; 
	};

	return 0;
};

void Pb7( )
{
  int sir[20], n, i;
  PLista pL;
//creare lista
  cout << "\nDati lungimea listei: ";
  cin >> n;
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL =( lista*) creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)
  cout << "\nLista data este: " << lista_e_multime( pL ) << "multime";
//cerinte: b)  
  cout << "\nNumarul de elem distincte este: " << nr_elem_distincte( pL );

};
	


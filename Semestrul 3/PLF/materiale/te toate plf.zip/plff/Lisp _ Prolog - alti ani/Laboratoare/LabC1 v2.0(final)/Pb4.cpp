#include "Lista.h"

/*
PB.4.a. Sa se determine numarul format prin insumarea elementelor de ordin par
           ale unei liste, din care se scad elementele de ordin impar ale listei
     b. Sa se determine produsul elementelor unei liste
*/

int numar_par_minus_impar( PLista &L )
{
	return 0;
};


int produs_elem( PLista &L )
{
	if( L != 0 )
	{
		int produs = L->inf * produs_elem( L->leg );
		return produs;
	};

	return 1;
};

void Pb4( )
{
//initializarea listei  
  int sir[20], n, i;
  PLista pL;
  cout << "\nDati lungimea listei: ";
  cin >> n;
  if( n == 0 ) 
  {
	cout << "\nAti dat lista vida!!" ;
	pL = creare_lista( 0, 0, 0 );
  }
  else
  {
	cout << "\nDati elementele listei: ";
	for( i = 0; i < n; i++ ) cin >> sir[i];
	pL = creare_lista( n, sir, 0 );
  };

//cerinte: a)
  cout << "\nPunctul a) nu a fost rezolvat! ";
//cerinte: b)  
  cout << "\nProdusul tuturor elem. din lista este: " << produs_elem( pL );
  	
};
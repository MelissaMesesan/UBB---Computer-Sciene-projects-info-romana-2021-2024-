#ifndef _Pb7_h
#define _Pb7_h

#include "Lista.h"

/*
PB.7.a. Sa se verifice daca o lista este multime
     b. Sa se determine numarul elementelor distincte dintr-o lista
*/
int lista_e_multime( PLista &L );
int nr_elem_distincte( PLista &L );

void Pb7( );

#endif

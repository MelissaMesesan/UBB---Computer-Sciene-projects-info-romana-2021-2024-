%b. Sa se scrie un predicat care, primind o lista, intoarce multimea 
%   tuturor perechilor din lista. De ex, cu [a, b, c, d] va produce 
%   [[a, b], [a, c], [a, d], [b, c], [b, d], [c, d]]. 


%append(L: list of numbers, K: list of numbers, R: Lista)
% R va lua valoarea alipirii celor doua liste, L si K
%append(i, i, o)
append([], [] , [] ) :-!.
append( L, [], L ) :- ! .
append( [], K, K ) :- ! .
append( [H1|T1], K, [H1|TR] ) :- append( T1, K, TR), ! .


%pair(e: number, L: list of numbers, R: list of pair)
% R va lua valoarea listei formata din perechile formate de numarul e si toate elementele din lista L
%pair(i, i, o)
pair( _, [], [] ) :- !.
pair( E, [H|T], [[E, H]|TR] ) :- pair( E, T, TR ).

%comb(L: list of numbers, R: Lista de perechi de numere)
% R va lua valoarea tuturor perechilor (x, y), x <> y, cu x, y apartinand listei L
%comb(i, o)
comb( [], [] ) :- !.
comb( [H|T], R ) :- pair( H, T, R1),
					 comb( T, R2),
					 append(R1, R2, R).
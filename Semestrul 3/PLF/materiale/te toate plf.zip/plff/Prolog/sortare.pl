insert(E,[],[E]).
insert(E,[H|T],[E|[H|T]]):-E<=H,!.
insert(E,[H|T],[H|L]):-E>H,insert(E,T,L).

sortare([],[]).
sortare([H|T],L) :- sortare(H,L1) , insert(H,L1,L).


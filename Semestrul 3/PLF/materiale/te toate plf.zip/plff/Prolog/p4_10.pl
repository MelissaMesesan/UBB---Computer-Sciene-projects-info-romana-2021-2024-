%P4 10. Se da sirul a1,..., an. Se cere sa se determine toate subsirurile strict
%crescatoare ale sirului a. 

%subsir(L : list of numbers, E : number ,R : list of numbers ).
%L - lista initiala de numere.
%R - lista rezultanta , in care vom avea subsirurile crescatoare.
%E - numar , acesta reprezentand un fel de comparator( indica daca elementele sunt crescatoare).
%(i,i,o)

subsir([],_,[]).
subsir([_|T],E,R):-subsir(T,E,R).
subsir([H|T],E,[H|R]):-H>E,subsir(T,H,R).

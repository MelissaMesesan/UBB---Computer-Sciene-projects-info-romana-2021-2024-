%a. Sa se scrie un predicat care intoarce reuniunea a doua multimi. 

%(E: number, L: list of numbers)
%este_membru (i, i)

este_membru( E , [ E | _ ]).
este_membru( E , [ _ | L ]) :- este_membru( E , L ) , !.

%(L: list of numbers, K: list of numbers, R: list of numbers)
%reuniune (i, i, o)

reuniune([] , K , K ) :- !. % Lista l e vida , deci doar K e
reuniune( [ H | T ] , K , R ) :- este_membru( H , K ) ,reuniune( T , K , R ) , ! .
reuniune( [ H | T ], K, [ H | R ] ) :- reuniune( T, K, R ).


%P3.Se da o lista formata din numere intregi. Se cere sa se elimine
% din lista toate subsirurile formate din valori consecutive.
%  Ex: [1, 3, 4, 2, 5, 6, 8] => [1, 2, 8]

% (L1: list of numbers, L2: list of numbers)
% L2 va reprezenta lista cu numere care va ramane dupa eliminarea subsirurilor cu valori consecutive.
%subs(i,o)


subs([],[]).
subs([H|[]],[H]).
subs([H,H1,H2|T],T1):- H1=:=H+1,H2=:=H1+1, subs([H1|[H2|T]],T1),!.
subs([H,H1|T],T1):- H1=:=H+1, subs(T,T1),!.
subs([H|T],[H|T1]):- subs(T,T1).

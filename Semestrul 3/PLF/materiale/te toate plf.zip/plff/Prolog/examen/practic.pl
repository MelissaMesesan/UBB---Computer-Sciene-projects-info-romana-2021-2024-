%elimin([],[]).
%elimin([H1,H2,H3|T],R) :- H1 mod 2 =:= 1 , H2 mod 2 =:=1 , H3 mod 2
%=:=1 , elimin([H2|[H3|T]],R),!.
%elimin([H1,H2|T],R) :- H1 mod 2 =:=1 , H2 mod 2 =:=1 , elimin(T,R),!.
%elimin([H|T],[H|R]) :- elimin( T,R),!.


find_p( _ , _ , 0).
find_p( X , P , S ) :- P =< X , X mod P =:= 0 , find_p( X , P , S1 ) , S is S1 + P .
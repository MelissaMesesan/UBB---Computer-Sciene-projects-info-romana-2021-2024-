%P2. Intr-o lista L sa se inlocuiasca toate aparitiile unui element E cu
% elementele unei alte liste, L1. Exemplu: inloc([1,2,1,3,1,4],1,[10,11],X)
% va produce X=[10,11,2,10,11,3,10,11,4].
 
% concatenare(L1: list of numbers, L2: list of numbers, R: Lista)
% R va lua valoarea alipirii celor doua liste, L1 si L2
% concatenare(i, i, o)

 concatenare([],[],[]).
 concatenare([],L,L).
 concatenare(L,[],L).
 concatenare([H|L1],L2,[H|L3]):-concatenare(L1,L2,L3).   
 
 % subst(e: number, L1: list of numbers , L2: list of numbers , L3: list of numbers)
 % L3 va reprezenta o lista obtinuta prin inlocuirea fiecarei aparitii a elemetului e cu lista L1.
 % subst(i,i,i,o)
 
 subst(_,_,[],[]).
 subst(E,L,[E|T],R):-subst(E,L,T,R1),concatenare(L,R1,R).
 subst(E,L,[H|T],[H|R]):- (E=\=H) , subst(E,L,T,R).
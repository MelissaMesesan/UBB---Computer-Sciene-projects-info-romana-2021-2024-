%sum_elem([],0).
%sum_elem([H|T],S) :- sum_elem(T,S1) , S is S1 + H.

%ultim_elem([X|[]],X).
%ultim_elem([_|Rest],X) :- ultim_elem(Rest,X).

%max_elem([],Max) :- write(Max).
%max_elem([H|T],Max) :- H > Max , max_elem(T,H) ; max_elem(T,Max).

%poz_max([],_,_,Poz) :- write(Poz).
%poz_max([H|T],Max,Contor,Poz) :- Contor1 is Contor+1 , Max < H , poz_max(T,H,Contor1,Contor1).
%poz_max([_|T],Max,Contor,Poz) :- Contor1 is Contor+1 , poz_max(T,Max,Contor1,Poz).

%poz_max([],_,_,Poz) :- write(Poz).
%poz_max([H|T], Max , Contor , Poz ) :- Contor1 is Contor + 1 , H > Max , poz_max(T,H,Contor1,Contor1) ; poz_max(T,Max,Contor1,Poz).

%inv1([], L, L).
%inv1([X|Rest], Temp, L) :- inv1(Rest, [X|Temp] , L).

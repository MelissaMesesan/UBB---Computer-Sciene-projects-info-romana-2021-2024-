%adauga(i,i,0)
%adauga_a(i,i,i,i,o)


adauga([],_,[]).
adauga(L1,V,L2):-Poz = 1,
                  Con = 1,
                  adauga_a(L1,V,Poz,Con,L2).

  adauga_a([],_,_,_,[]).

%atunci cand se indeplineste conditia de puterea lui 2 se adauga v
  adauga_a([H|T],V,Poz,Con,[H|[V|L]]):- Poz is (Con+1),!,
                                        Poz2 is Poz*2,
                                        Con2 is Con+1,
                                        adauga_a(T,V,Poz2,Con2,L).

%atunci cand nu se indeplineste aceasta conditie se incrementeaza con
  adauga_a([H|T],V,Poz,Con,[H|L]):-not(Poz=Con),!,
                                    Con2 is Con+1,
                                    adauga_a(T,V,Poz,Con2,L).

%domains
 % el = integer
  %list = el*
  
%predicates
 %  concatenare(list,list,list)  %(i,i,o)
  % subst(el,list,list,list) %(i,i,i,o)
   
%clauses
 concatenare([],L,L).
 concatenare([H|L1],L2,[H|L3]):-concatenare(L1,L2,L3).   

 subst(_,_,[],[]).
 subst(E,L,[E|T],R):-subst(E,L,T,R1),!,
                       concatenare(L,R1,R).
 subst(E,L,[H|T],[H|R]):-subst(E,L,T,R).

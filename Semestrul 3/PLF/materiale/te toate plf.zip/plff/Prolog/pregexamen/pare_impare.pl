par_imp([X],[],[X]).
par_imp([X,Y],[Y],[X]).
par_imp([X,Y|R],[Y|R2],[X|R3]) :- par_imp(R,R2,R3).
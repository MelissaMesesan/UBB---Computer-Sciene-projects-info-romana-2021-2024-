

inserez(E,[],[E]).
inserez(E,[H1|T1],[E|[H1|R]]) :- E<=H1,!.
inserez(E,[H1|T1],[H1|R]) :- H1>E , inserez(E,T1,R).
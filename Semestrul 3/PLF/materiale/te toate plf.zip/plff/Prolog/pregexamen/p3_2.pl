

adaug_s(E,[],[E]).
adaug_s(E,[H|T],[H|R]) :- adaug_s(E , T , R ).


inv([],[]).
inv([H|T1],R) :- inv(T1,R2) , adaug_s(H,R2,R).

suma([],[],[]):-!.
suma(L1,L2,R) :- inv(L1,I1) ,inv(L2,I2) , suma_aux(I1,I2,R3,0) , inv(R3,R).


suma_aux([],[],[],_) :- !.
suma_aux(L1,[H|L2],[M|R],N) :- L1=[] , S is H + N , M is S mod 10 , N1 is S div 10 , suma_aux(L1,L2,R,N1).
suma_aux([H|L1],L2,[M|R],N) :- L2=[] , S is H + N , M is S mod 10 , N1 is S div 10 , suma_aux(L1,L2,R,N1).
suma_aux([H1|L1],[H2|L2],[M|R],N) :- N = 0 , S is H1 + H2 , M is S mod 10 , N1 is S div 10 , suma_aux(L1,L2,R,N1).
suma_aux([H1|L1],[H2|L2],[M|R],N) :- N > 0 , S is H1 + H2 + N , M is S mod 10 , N1 is S div 10 , suma_aux(L1,L2,R,N1).




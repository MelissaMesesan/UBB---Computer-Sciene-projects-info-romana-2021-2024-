
baga([],[],_,_,_).
baga([H|T],[H|[E|R]],E,Poz1,Poz2) :- Poz1 mod 2 =:= 0 , Poz2 =:= Poz1* 2 , baga(T,R,E,Poz3,Poz4) , Poz1 is Poz3 + 1 , Poz2 is Poz4 + 2.
baga([H|T],[H|[E|R]],E,Poz1,Poz2) :- Poz1 mod 2 =\= 0 , baga(T,R,E,Poz3,Poz4) , Poz1 is Poz3 + 1 , Poz2 is Poz4 + 2.

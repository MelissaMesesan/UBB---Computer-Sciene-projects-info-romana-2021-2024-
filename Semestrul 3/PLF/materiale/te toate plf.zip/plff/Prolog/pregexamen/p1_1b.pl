sterge([],_,[]).
sterge([H|T],E,[H|R] ) :- H =\= E , sterge(T,E,R).
sterge([H|T],E,R) :- H = E , sterge(T,E,R).

numarare(E,[],0).
numarare(E,[H|T],N):-E=H,!,numarare(E,T,N1),N=N1+1.
numarare(E,[_|T],N):-numarare(E,T,N)

salvez([],[]).
salvez([H|T],[M|R] ) :- numarare(H,T,M) , salvez(T,R).
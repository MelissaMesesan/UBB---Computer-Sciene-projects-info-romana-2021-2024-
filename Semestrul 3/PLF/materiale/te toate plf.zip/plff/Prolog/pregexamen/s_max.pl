adag_f(E,[],[E]).
adag_f(E,[H|T],[H|R]) :- adag_f(E,T,R).

swap([],[]).
swap([H|T],R) :- swap(T,R2) , adag_f(H,R2,R).

suma([],[],[]).
suma(L1,L2,R) :- swap(L1,I1)  , swap(L2,I2) , rez(I1,I2,S,0) , swap(S,R).

rez([],[],[],_).
rez(T1,[H|T2],[M|R],N ) :-T1 = [] , S is H + N , M is S mod 10 , N1 is S div 10 , rez(T1,T2,R,N1).
rez([H|T1],T2,[M|R],N) :- T2 = [] , S is H + N , M is S mod 10 , N1 is S div 10 , rez(T1,T2,R,N1).
rez([H1|T1],[H2|T2],[M|R],N) :- S is H1 + H2 + N , M is S mod 10 , N1 is S div 10 , rez(T1,T2,R,N1).



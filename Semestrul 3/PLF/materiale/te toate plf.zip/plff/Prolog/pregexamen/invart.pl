
invarte([],L,L).
invarte([H|T],Temp , L) :- invarte(T,[H|Temp],L).
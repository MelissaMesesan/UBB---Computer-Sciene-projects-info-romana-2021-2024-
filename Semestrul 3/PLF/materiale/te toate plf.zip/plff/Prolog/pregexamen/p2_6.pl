

egal([],[]).
egal([H1|T1],[H2|T2]) :- H1 = H2 , egal(T1,T2).

lungime([],0).
lungime([H|T],N) :- lungime(T,N1) , N is N1 + 1.

mai_mic([],_).
mai_mic([H],[H1]) :- H < H1.
mai_mic(L1 , L2 ) :- lungime(L1,N1) , lungime(L2,N2 ) , N1 < N2.
mai_mic([H1|L1],[H2|L2]) :- H1 < H2 , mai_mic(L1,L2).
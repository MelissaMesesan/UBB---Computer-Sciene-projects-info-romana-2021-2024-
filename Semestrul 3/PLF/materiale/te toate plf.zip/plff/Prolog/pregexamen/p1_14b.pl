maxim([],-99999).
maxim([H|T],H) :- maxim(T,M) , M < H , !.
maxim([_|T],M) :- maxim(T,M).

solve(L,R) :- maxim(L,M) , solve2(L,R,M).

solve2([],[],_).
solve2([H|T],R,M) :- H =:= M , solve2(T,R,M),!.
solve2([H|T],[H|R],M) :- solve2(T,R,M),!.
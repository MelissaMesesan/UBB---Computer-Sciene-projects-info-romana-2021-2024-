%max_elem([],Max) :- write(Max),!.
%max_elem([H|T],Max) :- H > Max , max_elem(T,H) ; max_elem(T,Max)
%(i,i,i,o)
%poz_max([],_,_,Poz) :- Write(Poz).
%poz_max([P|R],Max,Contor,Poz) :- Contor1 is Contor + 1 , Max < P , poz_max(R,P,Contor1,Contor1); poz_max(R,Max,Contor1,Poz).


poz_max([],_,_,Poz) :- write(Poz).
poz_max([H|T],Max,Contor,Poz) :- Contor1 is Contor + 1 , H > Max , poz_max(T,H,Contor1,Contor1).
poz_max([_|T],Max,Contor,Poz) :- Contor1 is Contor + 1 , poz_max(T,Max,Contor1,Poz).
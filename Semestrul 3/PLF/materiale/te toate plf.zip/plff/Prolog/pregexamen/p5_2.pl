poli([H],X,R,N):- R is N*X+H , !.
poli([H|T],X,R,N):- N1 is N*X+H , poli(T,X,R,N1).
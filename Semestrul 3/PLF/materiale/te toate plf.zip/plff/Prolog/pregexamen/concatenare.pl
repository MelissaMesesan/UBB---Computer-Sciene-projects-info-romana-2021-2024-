concatenez([],L,L).
concatenez(L,[],L).
concatenez([H1|T1] , T2 , [H1|T3] ) :- concatenez(T1,T2,T3).
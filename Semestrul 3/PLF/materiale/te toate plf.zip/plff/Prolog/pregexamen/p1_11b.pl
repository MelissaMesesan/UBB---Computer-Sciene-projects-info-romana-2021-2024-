

aparitie(_,[],0):-!.
aparitie(E,[E|T],N):-  aparitie(E,T,N1),!,N is N1 + 1.
aparitie(E,[_|T],N):-aparitie(E,T,N).

elimina(E,L,R) :- elim(E,L,R,3).

elim(_,[],[],0).
elim(E,[H|L],R,C):- E =:= H , C2 is C - 1 , elim(E,L,R,C2).
elim(E,[H,L],[H|R],C) :- E =\= H , C2 is C - 1 , elim(E,L,R,C2).


este_membru(E,[E|_]).
este_membru(E,[_|T]) :- este_membru(E,T).

multime([],K,K).
multime([H|T],L,R) :- este_membru(H,L) , multime(T,L,R).
multime([H|T],L,[H|R] ) :- multime(T,L,R).
munte([H1,H2|T]) :- H1 < H2 , urc([H1|[H2|T]]).
urc([E]) :- fail.
urc([H1,H2|T]) :- H1 < H2 , urc([H2|T]).
urc([H1,H2|T]) :- H1 > H2 , cobor([H1|[H2|T]]).
cobor([E]) :- true.
cobor([H1,H2|T]) :- H1 > H2 , cobor([H2|T]).
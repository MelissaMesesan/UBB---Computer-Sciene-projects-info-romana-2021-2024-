
sum2(N,S) :- S is ( ( N + 1 ) * N div 2 ).

sum(0,0).
sum(N,S) :- N2 is N - 1 , sum(N2,S2) , S is S2 + N , !.

%Combinari
%combinar([],_,[]).
combinar([H|_],1,[H]).
combinar([_|T],K,R) :- combinar(T,K,R).
combinar([H|T],K,[H|R]) :- K > 1 , K2 is K - 1 , combinar(T,K2,R).

get_all(L,K,R) :- findall(X,combinar(L,K,X),R).

inseram(E,L,[E|L]).
inseram(E,[H|T],[H|R]) :- inseram(E,T,R).

permutare([],[]).
permutare([H|T],R) :- permutare(T,R2) , inseram(H,R2,R).

aranjamente(L,K,R) :- combinar(L,K,R2) , permutare(R2,R).


aranj_total(L,R,K) :- findall(X , aranjamente(L,K,X) , R).

suma_l([],0).
suma_l([H|T],S) :- suma_l(T,S1) , S is S1 + H.

prob2([],[],_).
prob2([H|T],[H|R],X) :- not(number(H)) , suma_l(H,P) , P =:= X , prob2(T,R,X),!.
prob2([_|T],R,X) :- prob2(T,R,X).

solve(L,R,K,S) :- aranj_total(L,R2,K) , prob2(R2,R,S).


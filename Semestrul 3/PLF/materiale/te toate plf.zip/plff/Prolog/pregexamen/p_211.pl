maxx([],-32000).
maxx([H|T],H) :- maxx(T,M) , M < H , !.
maxx([_|T],M) :- maxx(T,M).

pozz([],[]).
pozz(L,R) :- maxx(L,M) , afla_poz(L,R,M,1).

afla_poz([],[],_,_).
afla_poz([H|T],[P|R],M,P) :- H = M , P1 is P + 1 , afla_poz(T,R,M,P1).
afla_poz([_|T],R,M,P) :- P1 is P + 1 , afla_poz(T,R,M,P1).
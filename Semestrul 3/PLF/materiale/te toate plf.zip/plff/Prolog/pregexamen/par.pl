baga(_,[],[]).
baga(E,[H|T],[H|[E|R]]) :- H mod 2 =:= 0 , baga(E,T,R).
baga(E,[H|T],[H|R]) :- baga(E,T,R).
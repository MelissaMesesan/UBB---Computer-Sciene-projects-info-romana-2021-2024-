
maxim([],-99999).
maxim([H|T],H) :- maxim(T,M) , M < H , !.
maxim([_|T],M) :- maxim(T,M).


solve([],[]).
solve(L,R) :- maxim(L,M) , el(L,M,R).

el([],_,[]).
el([H|T],M,T) :- H =:= M.
el([H|T],M,[H|R] ) :- H=\= M , el( T , M , R ).


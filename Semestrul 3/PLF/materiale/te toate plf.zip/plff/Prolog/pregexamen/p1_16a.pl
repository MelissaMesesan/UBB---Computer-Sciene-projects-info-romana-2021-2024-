
apar(_,[],0) :-!.
apar(E,[E|T],N ) :-  apar(E,T,N1) ,!, N is N1 + 1.
apar(E,[_|T],N ) :- apar(E,T,N),!.

elii([],[]).
elii(T,R) :- solve(T,R,T).

solve([],[],_) :- !.
solve([H|T],R,L) :- apar(H,L,N ) , N =:= 1 , solve(T,R,L).
solve([H|T],[H|R],L) :- apar(H,L,N) , N =\= 1 , solve(T,R,L).



adaug(E,[],[E]).
adaug(E,[H1|T1],[H1|T2]) :- adaug(E,T1,T2).

invers([],[]).
invers([H|T],L) :- invers(T,L1) , adaug(H,L1,L).

succesor(L,R):-invers(L,LM),suc(LM,S,1),invers(S,R).
	
suc([],[],_) :- !.
suc([H|T],[H|L],N):- N = 0,!,suc(T,L,0).
suc([H|T],[M|L],N):- N > 0 ,! ,S is H+N , M is S mod 10,N1 is S div 10,suc(T,L,N1).
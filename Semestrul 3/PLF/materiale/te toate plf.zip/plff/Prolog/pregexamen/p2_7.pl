insert(E,[],[E]).
insert(E,[H|T],[E|[H|T]] ):- E =< H , !.
insert(E,[H|T],[H|R] ) :- E > H , insert(E,T,R).

sortare([],[]).
sortare([H|T],R) :- sortare(T,R1) , insert(H,R1,R).


cmmd_c(A,B,A) :- A = B.
cmmd_c(A,B,D) :- A > B , A1 is A - B , cmmd_c(A1,B,D).
cmmd_c(A,B,D) :- B > A , B1 is B - A , cmmd_c(A,B1,D).


cmmmc(A,B,M) :- P is A * B , cmmd_c(A,B,D) , M is P div D.

l_cmmmc([],1).
l_cmmmc([H|T],M) :- l_cmmmc(T,M2) , cmmmc(H,M2,M).

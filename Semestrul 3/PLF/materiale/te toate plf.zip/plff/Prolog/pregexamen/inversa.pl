inv1([],L,L).
inv1([X|Rest], Temp , Linv) :- inv1(Rest, [X|Temp] , Linv).

par([]).
par([H1,H2|T]) :- par(T).
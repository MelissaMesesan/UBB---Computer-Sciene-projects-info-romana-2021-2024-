sterg([],_,[]).
sterg([H|R],H,Rez) :- sterg(R,H,Rez).
sterg([H|R],E,[H|Rez] ) :- sterg(R,E,Rez).
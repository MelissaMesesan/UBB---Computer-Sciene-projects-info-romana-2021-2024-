add_fin(E,[],[E]).
add_fin(E,[H|T],[H|R] ):- add_fin(E,T,R).

invart([],[]).
invart([H|T],R) :- invart(T,L1) , add_fin(H,L1,R).


succ([],[]).
succ(T,R) :- invart(T,I1) , add_1(I1,S,1) , invart(S,R).

add_1([],[],_).
add_1([H|T],[H|R],N ) :- N = 0 , add_1(T,R,N).
add_1([H|T],[M|R],N ) :- N > 0 , S is H + N , M is S mod 10 , N1 is S div 10 , add_1(T,R,N1).

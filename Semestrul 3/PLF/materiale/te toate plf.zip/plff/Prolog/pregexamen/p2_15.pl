
elim([],[]).
elim([E|[]],[E]).
elim([H1,H2,H3|T],R) :- H2 =:= H1 + 1 , H3 =:= H2 + 1 , elim([H2|[H3|T]],R),!.
elim([H1,H2|T],R) :- H2 =:= H1 + 1 , elim(T,R).
elim([H1|T],[H1|R]) :- elim(T,R).
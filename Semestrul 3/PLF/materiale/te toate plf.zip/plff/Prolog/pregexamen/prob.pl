
suma([],0).
suma([H|T],S) :- suma(T,S2) , S is S2 + H.

%permutari

insert(E,L,[E|L]).
insert(E,[H|T],[H|R]) :- insert(E,T,R).

permutari([],[]).
permutari([H|T],R) :- permutari(T,R2) , insert(H,R2,R).


find_all(L,R) :- findall(X , permutari(L,X) , R ).

%combinari

combin([H|_],1,[H]).
combin([_|T],K,R) :- combin(T,K,R).
combin([H|T],K,[H|R]) :- K > 1 , K2 is K - 1 , combin(T,K2,R).

%aranjamente

aranj([],_,[]).
aranj(L,K,R) :- combin(L,K,R2) , permutari(R2,R).

find_ar(L,R,K) :- findall(X , aranj(L,K,X) , R ).

%submultimi

subm([],[]).
subm([H|T],[H|R]) :- subm(T,R).
subm([_|T],R) :- subm(T,R).

%aranjamente cu suma 

sum([],0).
sum([H|T],S) :- sum(T,S2) , S is S2 + H.

solve([],[],_).
solve([H|T],[H|R],S) :- not(number(H)) , sum(H,S2) , S2 =:= S , solve(T,R,S).
solve([_|T],R,S) :- solve(T,R,S).


solv(L,K,R,S) :- find_ar(L,R2,K) , solve(R2,R,S),!. 


%permutare cu prop
verif([_]).
verif([H1,H2|T]) :- abs(H1-H2)  =< 3 , verif([H2|T]) , !.
verif([H1,H2|_]) :- abs(H1-H2)  > 3 , fail , !.


solv2([],[]).
solv2([H|T],[H|R]) :- not(number(H)) , verif(H) , solv2(T,R).
solv2([_|T],R) :- solv2(T,R).

sollv(L,R) :- find_all(L,R2) , solv2(R2,R) , !.

prim(N) :- is_prime(N,2).

is_prime(N,K) :- I is N div 2 , K > I , !.
is_prime(N,K) :- R is N mod K , R =\= 0 , K2 is K + 1 , is_prime(N,K2) , !.



elm_prime([],[],_).
elm_prime([H|T],R,N) :- N > 0 , prim(H) , N2 is N - 1 , elm_prime(T,R,N2) ,!.
elm_prime([H|T],[H|R],N ) :- N =:= 0 , prim(H) , N2 is N - 1 , elm_prime(T,R,N2),!.
elm_prime([H|T],[H|R],N) :- elm_prime(T,R,N) , !.

%suma primelor n numere

sum2(N,S) :-  S is ( N * ( N + 1 ) div 2 ) .

sum3(0,0).
sum3(N,S):- N2 is N - 1 , sum3(N2,S2) , S is N + S2 , !.

%x ^ n

produs(_,0,1) :-!.
produs(X,N,P) :- N2 is N - 1 , produs(X,N2,P2) , P is P2 * X , !.

produs2(_,0,1) :-!.
produs2(A,B,P) :- B mod 2 =:= 1 , B2 is B div 2 , A2 is A * A , produs2(A2,B2,P2) , P is P2 * A,!.
produs2(A,B,P) :- B mod 2 =:= 0 , B2 is B div 2 , A2 is A * A , produs2(A2,B2,P2) , P is P2 , !.

append([],[],[]).
append(L,[],L).
append([],L,L).
append([H|T],L,[H|R] ) :- append(T,L,R).

pr(_,[],[]) :- !.
pr(E,[H|T],[[E,H]|R]) :- pr(E,T,R).

comb([],[]).
comb([H|T],R) :- pr(H,T,R2) , comb(T,R3) , append(R2 , R3 , R).
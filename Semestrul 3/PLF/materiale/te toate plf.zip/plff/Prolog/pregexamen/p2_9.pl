interclas([],[],[]).
interclas(L,[],L).
interclas([],L,L).
interclas([H1|L1],[H2|L2],[H1|L3]) :- H1 < H2 , interclas(L1, [H2|L2] , L3 ).
interclas([H1|L1],[H2|L2],[H2|L3]) :- H2 < H1 , interclas([H1|L1] , L2 , L3).
interclas([H1|L1],[H1|L2],[H1|L3]) :-  interclas(L1 , L2 , L3 ).
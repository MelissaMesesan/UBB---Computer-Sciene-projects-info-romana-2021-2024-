este_m(E,[E|_]).
este_m(E,[_|T]) :- este_m(E,T).


adaug([],[]).
adaug([H|T],R) :- este_m(H,T) , solve(H,T,L1) , adaug(L1,R) ,!.
adaug([H|T],[H|R] ) :- adaug(T,R).

solve(_,[],[]).
solve(E,[E|T],R) :- solve(E,T,R).
solve(E,[H|T],[H|R]) :- solve(E,T,R).
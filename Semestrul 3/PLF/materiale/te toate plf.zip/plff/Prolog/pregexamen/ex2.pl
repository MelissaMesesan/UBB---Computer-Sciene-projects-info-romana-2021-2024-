%suma elementelor dintr-o lista

suma([],0).
suma([H|T],S) :- suma(T,S1) , S is S1 + H.
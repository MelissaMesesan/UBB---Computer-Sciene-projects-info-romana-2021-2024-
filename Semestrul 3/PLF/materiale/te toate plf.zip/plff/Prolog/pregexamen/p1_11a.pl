
membru(E,[E|_]).
membru(E,[_|T]) :- membru(E,T).

multime([]).
multime([H|T]) :- not(membru(H,T)) , multime(T).
insert(E,T,[E|T]).
insert(E,[H|T],[H|R]) :- insert(E,T,R).

insert(E , L , [E|L]).
insert(E , [H|T] , [H|R] ) :- insert(E,T,R).

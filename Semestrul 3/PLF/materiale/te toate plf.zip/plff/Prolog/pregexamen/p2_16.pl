
ster([],[]).
ster([E|[]],[E]).
ster([H1,H2,H3|T],R) :- H1 =< H2 , H2 =< H3 , ster([H2|[H3|T]] , R).
ster([H1,H2|T],R) :- H1 =< H2 , ster(T,R).
ster([H|T],[H|R]) :- ster(T,R).
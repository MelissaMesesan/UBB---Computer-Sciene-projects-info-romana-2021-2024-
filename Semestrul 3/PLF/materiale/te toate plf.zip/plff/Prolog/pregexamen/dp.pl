este_membru(H,[H|_]).
este_membru(H,[_|T]) :- este_membru(H,T), !.

insert(E,[],[E]).
insert(E,[H|T],[E|[H|T]]):- E=<H,!.
insert(E,[H|T],[H|L]):- E>H,insert(E,T,L).

sortare([],[]).
sortare([H|T],L) :- este_membru(H,T) , sortare(T,L).
sortare([H|T],L) :-   sortare(T,L1) , insert(H,L1,L).


duplicate([],[]).
duplicate([H|T1],T2) :- este_membru(H,T1) , duplicate(T1,T2).
duplicate([H|T1],[H|T2]) :- duplicate(T1,T2).
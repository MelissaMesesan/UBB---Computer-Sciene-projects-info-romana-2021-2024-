este_membru(E,[E|_]).
este_membru(E,[_|T]) :- este_membru(E,T) , !.

inserez(E,[],[E]).
inserez(E,[H|T],[E|[H|T]]) :- E =< H , !.
inserez(E,[H|T],[H|R]) :- E > H , inserez(E,T,R).


sortare2([],[]).
sortare2([H|T1],R) :- este_membru(H,T1 ) , sortare2(T1,R).
sortare2([H|T1],R) :- sortare2(T1,R2) , insert(H,R2,R).

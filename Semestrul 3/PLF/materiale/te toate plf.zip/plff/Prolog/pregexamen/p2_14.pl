minim([],99999).
minim([H|T],H) :- minim(T,M) , H < M , !.
minim([_|T],M) :- minim(T,M).

poz2([],[]).
poz2(L,R) :- minim(L,M) , afla2(L,R,M,1).


afla2([],[],_,_).
afla2([H|T],[P|R],M,P) :- H = M , P1 is P + 1 , afla2(T , R , M , P1),!.
afla2([_|T],R,M,P) :- P1 is P + 1 , afla2(T,R,M,P1) , !.

concat([],[],[]).
concat([],L,L).
concat(L,[],L).
concat([H1|T1],T2,[H1|R1]) :- concat(T1,T2,R1).


sol(_,[],_,[]).
sol(E,[H|T],L,R) :- E = H , sol(E , T , L ,  R1 ) , concat(L,R1,R).
sol(E,[H|T],L,[H|R]) :- E =\= H , sol(E , T , L , R).



 
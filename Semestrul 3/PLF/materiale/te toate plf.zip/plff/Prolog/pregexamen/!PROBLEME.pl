
%(i,i,o)
%(lista , k , sum )
interclasez([],L,L).
interclasez(L,[],L).
interclasez([H1|T1],[H2|T2],[H1|R]) :- H1 < H2 , interclasez(T1,[H2|T2],R).
interclasez([H1|T1],[H2|T2],[H2|R]) :- H2 < H1 , interclasez([H1|T1],T2,R).
interclasez([H1|T1],[_|T2],[H1|R]) :- interclasez(T1,T2,R).

suma([],_,0 ) :-!.
suma([H|T],K,S) :- K1 is K-1 , suma(T,K1,S1) , S is S1 + H.

%baga elementele pare intr-o lista
lista([],[]).
lista([H|T],[H|Rez]) :- H mod 2 =:= 0 , lista(T,Rez).
lista([H|T],Rez) :- H mod 2 =:= 1 , lista(T,Rez).

%baga un element la finalul unei lista
lista([],E,[E]).
lista([H|T],E,[H|R] ) :- lista(T,E,R).

%fac perechi de forma (E l ) unde e < l

pereche(E,[H|_] , [E|H]) :- E < H.
pereche(E, [_|T] , R ) :- pereche( E , T , R).

%submultimi

subm([],[]).
subm([_|T],R) :- subm(T,R).
subm([H|T],[H|R]) :- subm(T,R).

%combinari
comb([H|_],1,[H]).
comb([_|T],K,R) :- comb(T,K,R).
comb([H|T],K,[H|R] ) :- K1 is K -1 , comb(T,K1,R).

%inserez un element pe toate pozitiile

insert(E , L , [E|L]).
insert(E , [H|T] , [H|R] ) :- insert(E,T,R).

%generez permutari
permut([],[]).
permut([H|T],P) :- permut(T,P1) , insert(H,P1,P).

%membrul unei liste
member(E,[E|_]) :-!.
member(E,[_|T]) :- member(E,T).

%suma elementelor dintr-o lista
suma([],0).
suma([H|T],S) :- suma(T,S1) , S is S1 + H.

maxim([],-99999).
maxim([H|T],H) :- maxim(T,M) , M < H , !.
maxim([_|T],M) :- maxim(T,M).

minim([],99999).
minim([H|T],H) :- minim(T,M) , H < M , !.
minim([_|T],M) :- minim(T,M).

stergere(L,R) :- maxim(L,M) , sterg(L,R,M).

sterg([],[],_).
sterg([H|T],R,M) :- H =:= M , sterg(T,R,M) , !.
sterg([H|T],[H|R],M) :- H =\= M , sterg(T,R,M) , !.

poz_max(L,R) :- maxim(L,M) , det_poz(L,M,1,R).

det_poz([],_,_,[]).
det_poz([H|T],M,Poz,[Poz|R] ) :- H =:= M , Poz2 is Poz + 1 , det_poz(T,M,Poz2,R) , !.
det_poz([H|T],M,Poz,R) :- H =\= M , Poz2 is Poz + 1 , det_poz(T,M,Poz2,R) , !.

%adaug la final
adaug_final(E,[],[E]).
adaug_final(E,[H|T],[H|R]) :- adaug_final(E,T,R).

%inversez o lista
invers([],[]).
invers([H|T],R) :- invers(T,R2) , adaug_final(H,R2,R).

%elemnnetul de pe poz i
poz_el([X|_],1,X).
poz_el([_|T],I,E) :- I1 is I - 1 , poz_el(T,I1,E).

%elimina duplicate
este_m(E,[E|_]) :-!.
este_m(E,[_|T] ):- este_m(E,T),!.


elimin_dup([],[]).
elimin_dup([H|T],R) :- este_m(H,T) , elimin_dup(T,R).
elimin_dup([H|T],[H|R]) :- elimin_dup(T,R).


%verific numar prim

prim(N) :- primulet(N,2).

primulet(N,K) :- I is N div 2 , K > I , !.
primulet(N,K) :- R is N mod K , R =\= 0 , K1 is K + 1 , primulet(N,K1) , !.

%L3 -1 ( elimina dintr-o lista toate subsirurile de valori crescatoare)

eli_subsir([],[]).
eli_subsir([H1,H2,H3|T],R) :- H1 =:= H2 + 1 , H2 =:= H3 + 1 , eli_subsir([H2,H3|T],R),!.
eli_subsir([H1,H2|T],R) :- H2 =:= H1 + 1 , eli_subsir(T,R),!.
eli_subsir([H|T],[H|R]) :- eli_subsir(T,R),!.

%L3-3 adauga un element din 2 in 2

adaug_ele(L,E,R) :- add(L,E,R,1).

add([],_,[],_).
add([H|T],E,[H,E|R],Poz) :- Poz mod 2 =:= 0 , Poz2 is Poz + 1 , add(T,E,R,Poz2) , !.
add([H|T],E,[H|R],Poz) :- Poz2 is Poz + 1 , add(T,E,R,Poz2) , !.

%L4 - sterge numerele prime

prim2(N) :- verif_prim(N,2).
verif_prim(N,K) :- I is N div 2 , K > I , !.
verif_prim(N,K) :- R is N mod K , R =\= 0 , K2 is K + 1 , verif_prim(N,K2) , !.

sterg_prime([],[]).
sterg_prime([H1,H2,H3|T],R) :- prim2(H1) , prim2(H2) , prim2(H3) , sterg_prime([H2,H3|T],R) , !.
sterg_prime([H1,H2|T],R) :- prim2(H1) , prim2(H2) , sterg_prime(T,R) , !.
sterg_prime([H|T],[H|R]) :- sterg_prime(T,R) , !.

%L2 - elimina secvente de subliste

eli2([],[]).
eli2([ l(L) |[]] , [l(L) |[]]).
eli2([ l(_) , l(_) , l(_) | T],R) :- eli2([l(_),l(_)|T],R) , !.
eli2([ l(_) , l(_) |T ],R) :- eli2(T,R) , !.
eli2( [ i(N) | T ] , [ i(N) | R ] ) :- eli2(T,R) , !. 
eli2([l(L1)|[i(N)|T]],[l(L1)|[i(N)|T1]]):-elim(T,T1).

%L7 - vezi suma elementelor pare a primelor subliste

suma_pare([],0).
suma_pare([H|T],S) :- H mod 2 =:= 0 ,! , suma_pare(T,S1) , S is S1 + H.
suma_pare([_|T],S) :- suma_pare(T,S).

suma_liste([],0,_).
suma_liste(_,0,0).
suma_liste([l(L)|T],S,N) :- N > 0 , ! , N1 is N - 1 , suma_pare(L,S2) , suma_liste(T,S3,N1) , S is S2 + S3.
suma_liste([_|T],S,N) :- suma_liste(T,S,N) , !.

%L9 - dupa fiecare numar care nu e prim introduc divizorii

is_prime(N) :- not(is_p(N,2)) .

is_p(N,K) :- I is N div 2 , K > I , !.
is_p(N,K) :- P is N mod K , P =\= 0 , K1 is K + 1 , is_p(N,K1) , !.

det_div(N,L) :- div(N,N,L).

div(_,1,[1]):-!.
div(N,D,[D|L]):-N mod D =:=0,!,D2 is D-1,div(N,D2,L).
div(N,D,L):-D2 is D-1,div(N,D2,L). 

inser_ul(E,[],[E]).
inser_ul(E,[H|T],[H|R]) :- inser_ul(E,T,R),!.

conc([],[],[]):-!.
conc(L,[],L):-!.
conc([],L,L):-!.
conc(L,[H|T],[H|R]) :- conc(L,T,R) , !.


solve(L,R) :- solve_grand(L,[],R).
solve_grand([],L,L) :-!.
solve_grand([H|T],L1,L) :- is_prime(H) , inser_ul(H,L1,L2) , div(H,L3) , conc(L2,L3,L4) , solve_grand(T,L4,L),!.
solve_grand([H|T],L1,L) :- inser_ul(H,L1,L2) , solve_grand(T,L2,L).

%p2

inns_ul(E,[],[E]).
inns_ul(E,[H|T],[H|R]) :- inns_ul(E,T,R).

swap([],[]).
swap([H|T],R) :- swap(T,R2) , inns_ul(H,R2,R).

next_el(L,R) :- swap(L,I1) , adun_tr(I1,R2,1) , swap(R2,R).

adun_tr([],[],_) :-!.
adun_tr([H|T1],[H|T2],N) :- N =:= 0 , adun_tr(T1,T2,N) , !.
adun_tr([H|T1],[M|T2],N) :- N > 0 , S is N + H , M is S mod 10 , N2 is S div 10 , adun_tr(T1,T2,N2). 


%p3-7

adun_par([],0) :-!.
adun_par([H|T],S) :- H mod 2 =:= 0 ,!, adun_par(T,S2) , S is S2 + H.
adun_par([_|T],S) :- adun_par(T,S),!.

sum_subl([],_,0).
sum_subl(_,0,0).
sum_subl([H|T],N,S) :- not(number(H)) , adun_par(H,R) , N2 is N - 1 , sum_subl(T,N2,S2) , S is R + S2 , !.
sum_subl([_|T],N,S) :- sum_subl(T,N,S) , !.

%p3-6

maxxim([],-9999).
maxxim([H|T],H) :- maxxim(T,M) , M < H , !.
maxxim([_|T],M) :- maxxim(T,M).

inloc(L,E,R) :- maxim(L,M) , epa(L,E,M,R).

inloc_el([],_,_,[]).
inloc_el([H|T],E,E2,[E2|R]) :- H =:= E , inloc_el(T,E,E2,R),!.
inloc_el([H|T],E,E2,[H|R]) :- inloc_el(T,E,E2,R),!.

epa([],_,_,[]).
epa([H|T],E,M,[[E]|R]) :- number(H) ,  H =:= M , epa(T,E,M,R).
epa([H|T],E,M,[H|R]) :- not(number(H)) , epa(T,E,M,R).
epa([_|T],E,M,R) :- epa(T,E,M,R).

%p3-5

dublu_pare([],[]).
dublu_pare([H|T],[H|R]) :- H mod 2 =:= 1 , dublu_pare(T,R) , !.
dublu_pare([H|T],[D|R]) :- H mod 2 =:= 0 , D is H * 2 , dublu_pare(T,R) , !.

dublez([],[]).
dublez([H|T],[H|R] ) :- number(H) , dublez(T,R) , !.
dublez([H|T],[R1|R] ) :- dublu_pare(H,R1) , dublez(T,R) , !.

%p3-11

elimi(L,R,N) :- baga_eli(L,1,N,R).

baga_eli([],_,_,[]).
baga_eli([H|T],Poz,N,[H|R]) :- Poz mod N =\= 0 , Poz2 is Poz + 1 , baga_eli(T,Poz2,N,R) , !.
baga_eli([_|T],Poz,N,R) :- Poz2 is Poz + 1 , baga_eli(T,Poz2,N,R) , !.

elimina_subbl( L , R , N ) :- elimii2(L,R,N,1).
elimii2([],[],_,_).
elimii2([H|T],[H|R],N,Poz) :- number(H) , Poz mod N =\= 0 , Poz2 is Poz + 1 , elimii2(T,R,N,Poz2) , !.
elimii2([H|T],[R1|R],N,Poz) :- not(number(H)) , elimi(H,R1,N) , Poz2 is Poz + 1 , elimii2(T,R,N,Poz2) , !.
elimii2([_|T],R,N,Poz ) :- Poz2 is Poz + 1 , elimii2(T,R,N,Poz2) , !.

%p3-16
insereazaa(L,R,M,E) :- ins_l(L,R,M,E,1).

ins_l([],[],_,_,_).
ins_l([H|T],[E|[H|R]],M,E,Poz) :- Poz mod M =:= 0 , Poz2 is Poz + 1 , ins_l(T,R,M,E,Poz2) , !.
ins_l([H|T],[H|R],M,E,Poz ) :- Poz2 is Poz + 1 , ins_l(T,R,M,E,Poz2) , !.

%p2 -2 predecesorul unui numar

adaa(E,[],[E]).
adaa(E,[H|T],[H|R]) :- adaa(E,T,R).

inversa([],[]).
inversa([H|T],R) :- inversa(T,R2) , adaa(H,R2,R).

scade_tr(L,R) :- inversa(L,I1) , scade(I1,I2,1) , inversa(I2,R).

scade([],[],_).
scade([H|T],[D|R],N) :- H >= N , D is H - N  , scade(T,R,0) , !.
scade([H|T],[H|R],N) :- N =:=0 , scade(T,R,0) ,!.
scade([H|T],[D|R],N) :- H < N , D is 10 + H - N , scade(T,R,1) , !.

%p3 - 3 suma a doua numere in repr

suma_mare([],[],[]).
suma_mare(L1,L2,R) :- inversa(L1,I1) , inversa(L2,I2) , suma_aux(I1,I2,I3,0) , inversa(I3,R).

suma_aux([],[],[],_).
suma_aux(L1,[H|T],[M|R],N) :- L1=[] , S is H + N , M is S mod 10 , N is S div 10 , suma_aux(L1,T,R,N).
suma_aux([H|T],L2,[M|R],N) :- L2=[] , S is H + N , M is S mod 10 , N is S div 10 , suma_aux(T,L2,R,N).
suma_aux([H1|T1],[H2|T2],[M|R],N) :- S is H1 + H2 + N , M is S mod 10 , N is S div 10 , suma_aux(T1,T2,R,N).

dif_mare([],[],[]).
dif_mare(L1,L2,R) :- inversa(L1,I1) , inversa(L2,I2) , dif_aux(I1,I2,I3,0) , inversa(I3,R).

dif_aux([],[],[],_).
dif_aux(L1,[H|T],[M|R],N) :- L1=[] , H >= N , S is H - N , M is S mod 10 , dif_aux(L1,T,R,0).
dif_aux(L1,[H|T],[M|R],N) :- L1=[] , H < N , S is H + 10 - N , M is S mod 10 , dif_aux(L1,T,R,1).
dif_aux([H|T],L2,[M|R],N) :- L2=[] , H >= N , S is H - N , M is S mod 10 , dif_aux(T,L2,R,0).
dif_aux([H|T],L2,[M|R],N) :- L2=[] , H < N , S is H + 10 - N , M is S mod 10 , dif_aux(T,L2,R,1).
dif_aux([H1|T1],[H2|T2],[M|R],N) :- H1 >= H2 + N , S is H1 - H2 - N , M is S mod 10 , dif_aux(T1,T2,R,0).
dif_aux([H1|T1],[H2|T2],[M|R],N) :- H1 < H2 + N , S is H1 + 10 - H2 - N , M is S mod 10 , dif_aux(T1,T2,R,1).

%p2-7 sorteaza o lista

insert2(E,[],[E]).
insert2(E,[H|T],[E|[H|T]] ):- E =< H , !.
insert2(E,[H|T],[H|R] ) :- E > H , insert2(E,T,R).

sorta([],[]).
sorta([H|T],R) :- sorta(T,R2) , insert2(H,R2,R).

%p2-8 sort o lista fara duplicate

este_mm([E|_],E).
este_mm([_|T],E) :- este_mm(T,E).

elimm_dup([],[]).
elimm_dup([H|T],R) :- este_mm(T,H) , elimm_dup(T,R).
elimm_dup([H|T],[H|R]) :- elimm_dup(T,R).

sortaret(L,R) :- elimin_dup(L,R1) , sorta(R1,R).

%p2-11 da poz elementelor maxime

maximus([],-99999).
maximus([H|T],H) :- maximus(T,M) , H > M , !.
maximus([_|T],M) :- maximus(T,M).

poz_max2(L,R) :- maximus(L,M) ,  afla_totu(L,R,M,1).

afla_totu([],[],_,_).
afla_totu([H|T],[Poz|R],M,Poz) :- H =:= M , Poz2 is Poz + 1 , afla_totu(T,R,M,Poz2).
afla_totu([H|T],R,M,Poz) :- H =\= M , Poz2 is Poz + 1 , afla_totu(T,R,M,Poz2).

cac([],[],[]).
cac(L,[],L).
cac([],L,L).
cac([H|T1],L2,[H|L3]) :- cac(T1,L2,L3).

subb([],_,_,[]).
subb([H|T1],L,E,R) :- H =:= E , subb(T1,L,E,R2) , cac(L,R2,R).
subb([H|T1],L,E,[H|R]) :- subb(T1,L,E,R).

%p1-3a
interc([],[],_,_).
interc([H|T],[E|[H|T]],1,E).
interc([H|T],[H|R],N,E) :- N2 is N - 1 , interc(T,R,N2,E).

%p1-3b
cmmdc(A,B,A) :- A =:= B.
cmmdc(A,B,D) :- B > A , B1 is B - A , cmmdc(A,B1,D).
cmmdc(A,B,D) :- A > B , A1 is A - B , cmmdc(A1,B,D).

lcmmdc([],1).
lcmmdc([E],E).
lcmmdc([H|T],D) :- lcmmdc(T,D2) , cmmdc(H,D2,D).

%p1-5a

par([]).
par([H1,H2|T]) :- par(T).

%p1-5b

miin([],99999).
miin([H|T],H) :- miin(T,M) , H < M , !.
miin([_|T],M) :- miin(T,M).

elim_app(L,R) :- miin(L,M) , eel(L,R,M).

eel([],[],_).
eel([H|T],T,M) :- H =:= M .
eel([H|T],[H|R],M) :- eel(T,R,M).

%p1-10a
cmmdc2(A,B,A) :- A =:=B.
cmmdc2(A,B,D) :- B > A , B1 is B - A , cmmdc2(A,B1,D).
cmmdc2(A,B,D) :- A > B , A1 is A - B , cmmdc2(A1,B,D).

cmmmc(A,B,A) :- A =:= B.
cmmmc(A,B,P) :- X is A * B , cmmdc(A,B,C) , P is X div C.


lcmmmc2([],1).
lcmmmc2([E],E).
lcmmmc2([H|T],D) :- lcmmmc2(T,D2) , cmmmc(H,D2,D).


%p1-11a

este_ma(E,[E|_]).
este_ma(E,[_|T]) :- este_ma(E,T) .


multime([]).
multime([H|T]) :- not(este_ma(H,T)) , multime(T).

%p1-14a

nraap(E,[],0).
nraap(E,[H|T],S) :- E =:= H , nraap(E,T,S1), S is S1 + 1 ,!.
nraap(E,[_|T],S) :- nraap(E,T,S) , !.

rez_lista([],[],L).
rez_lista([H|T],[H|R],L) :- nraap(H,L,C) , C =:= 1 , rez_lista(T,R,L) , !.
rez_lista([_|T],R,L) :- rez_lista(T,R,L) , !.



%p1-15a

vale([H1,H2|T]) :- H1 > H2 , cobor([H1,H2|T]).
cobor([E]) :- fail.
cobor([H1,H2|T]) :- H1 > H2 , cobor([H2|T]).
cobor([H1,H2|T]) :- H1 < H2 , urc([H1,H2|T]).

urc([E]) :- true.
urc([H1,H2|T]) :- H1 < H2 , urc([H2|T]).

%p1-16a

munte([H1,H2|T]) :- H1 < H2 , urc2([H1,H2|T]).

urc2([E]) :- fail.
urc2([H1,H2|T]) :- H1 < H2 , urc2([H2|T]).
urc2([H1,H2|T]) :- H1 > H2 , coboara2([H1,H2|T]).

coboara2([E]) :- true.
coboara2([H1,H2|T]) :- H1 > H2 , coboara2([H2|T]).

%p1-16b

%recapitulari
de_perechi(_,[],[]).
de_perechi(E,[H|_],[E|H]) :- E < H.
de_perechi(E,[_|T],P) :- de_perechi(E,T,P).

%submultimi
submult([],[]).
submult([H|T],[H|R]) :- submult(T,R).
submult([_|T],R) :- submult(T,R).

%combinari
combinam([H|_],1,[H]).
combinam([_|T],K,R) :- combinam(T,K,R).
combinam([H|T],K,[H|R]) :- K > 1 , K1 is K - 1 , comb(T,K1,R).

%insereaza_pe_toate_pozitiile
ins(E,L,[E|L]).
ins(E,[H|T],[H|R]) :- ins(E,T,R).

%generare de permutari
permutare([],[]).
permutare([H|T],P) :- permutare(T,P2) , ins(H,P2,P).

%generez combinari de o suma data

combb([H|_],1,H,[H]).
combb([_|T],K,S,R) :- combb(T,K,S,R).
combb([H|T],K,S,[H|R]) :- K > 1 , H < S , K1 is K - 1 , S1 is S - H , combb(T,K1,S1,R).


%submultimi
submm([],[]).
submm([_|T],R) :- submm(T,R).
submm([H|T],[H|R]) :- submm(T,R).

adev_subm(L,R) :- findall(X,submm(L,X),R).

%combinari
combina([H|_],1,[H]).
combina([_|T],K,R) :- combina(T,K,R).
combina([H|T],K,[H|R]) :- K > 1 , K1 is K - 1 , combina(T,K1,R).
adev_comb(L,R,K) :- findall(X, combina(L,K,X),R).

%permutari
inser(E,L,[E|L]).
inser(E,[H|L],[H|R]) :- inser(E,L,R).

permu([],[]).
permu([H|T],R) :- permu(T,R2) , inser(H,R2,R).
adev_permu(L,R) :- findall(X,permu(L,X),R).



%aranjamente
aranjamente(L,R,K) :- combina(L,K,R2) , permut(R2,R).
adev_aranjamente(L,R,K) :- findall(X,aranjamente(L,X,K),R).
 
% generare de comb de o suma data

comb_sum([H|_],1,H,[H]).
comb_sum([_|T],K,S,R) :- comb_sum(T,K,S,R).
comb_sum([H|T],K,S,[H|R]) :- K > 1 , H < S , K1 is K -1 , S1 is S - H , comb_sum(T,K1,S1,R).

%generare submultimi de o suma data

gen_subm([H|T],H,[H]).
gen_subm([_|T],S,R) :- gen_subm(T,S,R).
gen_subm([H|T],S,[H|R]) :- H < S , S > 0 ,  S2 is S - H , gen_subm(T,S2,R).

%generare de paranteze( 0 e paranteza dechisa , 1 e inchisa ).

paranteze(N,R) :- N mod 2 =:= 0 , N2 is N div 2 , catalan(N2,0,0,R).

catalan(N,N,N,[]).
catalan(N,D,I,[0|R]) :- D < N , D2 is D + 1 , catalan(N,D2,I,R).
catalan(N,D,I,[1|R]) :- I < D , D =< N , I2 is I + 1 , catalan(N,D,I2,R).


%toate subsirurile crescatoare
subsir([],_,[]).
subsir([_|T],E,R) :- subsir(T,E,R).
subsir([H|T],E,[H|R]) :- H > E , subsir(T,H,R).

adev_subsir(L,R) :- findall(X,subsir(L,0,X),R).

prime2(N):- iss_prim(N,2).

iss_prim(N,K) :- I is N div 2 , K > I , !.
iss_prim(N,K) :- P is N mod K , P =\= 0 , K2 is K + 1 , iss_prim(N,K2).

%afisez submultimile care au suma elementelor divizibila cu un numar D

suma5([],0).
suma5([H|T],S) :- suma5(T,S2) , S is S2 + H.

submm2([],[]).
submm2([_|T],R) :- submm2(T,R).
submm2([H|T],[H|R]) :- submm2(T,R).

gata_tot(L,R,D) :- totul(L,X) , solvv(X,R,D).

totul(L,R) :- findall(X,submm2(L,X),R).

solvv([],[],_).
solvv([H|T],[H|R],D) :- not(number(H)) , suma5(H,P) , P mod D =:=0 , solvv(T,R,D),!.
solvv([_|T],R,D) :- solvv(T,R,D),!.

%afisez subm de k elemente care au elementele in prog aritmetica

verif_boss([]).
verif_boss([H1,H2,H3]) :- (H1 + H3 ) mod 2 =:= 0 , H2 =:= H1 + H3 div 2.

pt_verificare(L) :- verif_boss(L) .

combinamente([H|T],1,[H]).
combinamente([_|T],K,R) :- combinamente(T,K,R).
combinamente([H|T],K,[H|R]) :- K > 1 , K2 is K - 1 , combinamente(T,K2,R).


finall_comb(L,R,D) :- combinam_all(L,D,X) , save_list(X,R).

combinam_all(L,D,R) :- findall(X,combinamente(L,D,X),R).

save_list([],[]).
save_list([H|T],[H|R]) :- pt_verificare(H) , save_list(T,R),!.
save_list([_|T],R) :- save_list(T,R),!.


%afisez aranjamentele care au suma elementelor divizibile cu K = 3.

combinn([H|T],1,[H]).
combinn([_|T],K,R) :- combinn(T,K,R).
combinn([H|T],K,[H|R]) :- K > 1 , K2 is K - 1 , combinn(T,K2,R).

iss(E,L,[E|L]).
iss(E,[H|L],[H|R]) :- iss(E,L,R).

perm([],[]).
perm([H|T],R) :- perm(T,R2) , iss(H,R2,R).

aranj_ament(L,R,K) :- combinn(L,K,X) , perm(X,R).

aranjez_totu(L,R,K) :- aranj_totu(L,X,K) , sava_list(X,R,3).

aranj_totu(L,R,K) :- findall(X,aranj_ament(L,X,K),R).

suma([],0).
suma([H|T],S) :- suma(T,S2) , S is H + S2.

sava_list([],[],_).
sava_list([H|T],[H|R],D) :- suma(H,S) , S mod D =:= 0 , sava_list(T,R,D) , !.
sava_list([_|T],R,D) :- sava_list(T,R,D),!.

	


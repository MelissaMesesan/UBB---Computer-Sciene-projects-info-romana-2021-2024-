interclasez([],L,L).
interclasez(L,[],L).
interclasez([H1|T1], [H2|T2 ] , [H1|T3] ) :- H1 < H2 , interclasez(T1,[H2|T2],T3).
interclasez([H1|T1] , [H2|T2] , [H2|T3] ) :- H2 < H1 , inteclasez( [H1|T1] , T2 , T3 ).
interclasez([H1|T1] , [H1|T2] , [H1|T3] ) :- inteclasez( T1 , T2 , T3 ).

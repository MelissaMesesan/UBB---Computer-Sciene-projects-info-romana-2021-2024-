

adauga_la(E,[],[E]).
adauga_la(E,[H|T],[H|R]) :- adauga_la(E,T,R).

swap2([],[]).
swap2([H|T],R) :- swap2(T,R2) , adauga_la(H,R2,R).

dif([],[],[]) :- !.
dif(L1,L2,R) :- swap2(L1,I1) , swap2(L2,I2) , dif_aux(I1,I2,R2,0) , swap2(R2,R).

dif_aux([],[],[],_) :- !.
dif_aux(L1,[H2|L2],[M|L3],N) :- L1=[] , N =< H2 , M is H2 - N , dif_aux(L1,L2,L3,0).
dif_aux(L1,[H2|L2],[M|L3],N) :- L1=[] , N > H2 , M is 10 - N , dif_aux(L1,L2,L3,1).
dif_aux([H1|L1],L2,[M|L3],N) :- L2=[] , N =< H1 , M is H1 - N , dif_aux(L1,L2,L3,0).
dif_aux([H1|L1],L2,[M|L3],N) :- L2=[] , N > H1 , M is 10 - N , dif_aux(L1,L2,L3,1).
dif_aux([H1|L1],[H2|L2],[M|L3],N) :- N = 0 , H2 =< H1 , M is H1 - H2 , dif_aux(L1,L2,L3,0).
dif_aux([H1|L1],[H2|L2],[M|L3],N) :- N = 0 , H2 > H1 , M is 10 + H1 - H2 , dif_aux(L1,L2,L3,1).
dif_aux([H1|L1],[H2|L2],[M|L3],N) :- N > 0 , H2 + N =< H1 , M is H1 - H2 - N , dif_aux(L1,L2,L3,0).
dif_aux([H1|L1],[H2|L2],[M|L3],N) :- N > 0 , H2 + N > H1 , M is 10 + H1 - H2 - N , dif_aux(L1,L2,L3,1).
 
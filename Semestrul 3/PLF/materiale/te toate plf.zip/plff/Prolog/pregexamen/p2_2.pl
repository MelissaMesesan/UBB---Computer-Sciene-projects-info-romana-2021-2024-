
adaug_f(E,[],[E]).
adaug_f(E,[H|T1],[H|T2] ) :- adaug_f(E,T1,T2).


swap([],[]).
swap([H|T1],R) :- swap(T1,R2) , adaug_f(H,R2,R).

predecesor(L,R) :- swap(L,R2) , pred(R2,R3,1) , swap(R3,R).

pred([],[],_) :- !.
pred([H|T1],[H|T2],N) :- N = 0 , ! , pred(T1,T2,N).
pred([H|T1],[M|T2],N) :- N > 0 , N =< H , M is H - N , pred(T1,T2,0).
pred([H|T1],[M|T2],N) :- N = 1 , H = 0 , M is 10 - N , pred(T1,T2,1). 


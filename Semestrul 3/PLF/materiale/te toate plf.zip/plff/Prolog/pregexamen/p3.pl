

verif_prim(N) :- este_prim(N,2).


este_prim(N,K) :- I is div(N,2) , K > I , !.
este_prim(N,K) :- P is N mod K , P =\= 0 , K1 is K + 1 , este_prim(N,K1).


eliminam_prime([],[],_).
eliminam_prime([H|T],R,N) :- verif_prim(H) , N > 0 , N2 is N - 1 , eliminam_prime(T,R,N2).
eliminam_prime([H|T],[H|R],N) :- verif_prim(H) ,  N =:= 0 , eliminam_prime(T,R,N).
eliminam_prime([H|T],[H|R],N) :-  not(verif_prim(H)) , eliminam_prime(T,R,N).

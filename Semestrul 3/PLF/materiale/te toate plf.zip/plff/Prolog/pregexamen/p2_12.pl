
concatenare([],[],[]).
concatenare(L,[],L).
concatenare([],L,L).
concatenare([H1|T1],T2,[H1|T3]) :- concatenare(T1,T2,T3).


subs(_,_,[],[]).
subs(E,L,[H|T],R):- E = H , subs(E,L,T,R1) , concatenare(L,R1,R).
subs(E,L,[H|T],[H|R]) :- E =\=H ,  subs(E,L,T,R).

 
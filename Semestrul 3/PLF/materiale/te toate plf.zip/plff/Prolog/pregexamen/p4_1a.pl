
subst([],[],_,_).
subst([H|T],[E2|R],E1,E2) :- H = E1 , subst(T,R,E1,E2).
subst([H|T],[H|R] , E1 , E2 ) :- H =\= E1 , subst(T,R,E1,E2).
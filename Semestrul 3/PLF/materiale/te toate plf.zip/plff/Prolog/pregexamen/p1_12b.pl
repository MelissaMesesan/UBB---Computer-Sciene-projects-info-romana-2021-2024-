

slc([],_,-1).
slc([H|_],N,H) :- N = 1 , !.
slc([_|T],N,E) :- N1 is N - 1 , slc(T,N1,E).
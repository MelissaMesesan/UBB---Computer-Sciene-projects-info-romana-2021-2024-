elim([],[],_,_).
elim([H|T],[H|R],Poz,N) :- Poz mod N =\= 0 , Poz2 is Poz + 1 , elim(T,R,Poz2,N).
elim([_|T],R,Poz,N) :- Poz mod N =:= 0 , Poz2 is Poz + 1 , elim(T,R,Poz2,N).
egal([],[]).
egal([H1],[H2]) :- H1 = H2.
egal([H1|T1],[H2|T2]) :- H1 = H2 , egal(T1,T2).


eli([],[],_,_,_).
eli([H|T],[H|R],E1,Poz,M) :- Poz mod M =\=  0 , Poz2 is Poz + 1 , eli(T,R,E1,Poz2,M).
eli([H|T],[H|[E1|R]],E1,Poz,M) :- Poz mod M =:= 0 , Poz2 is Poz + 1 , eli(T,R,E1,Poz2,M).

%( E : element , L1 : list of elements , L2 : list of elements).
%( i , i , o ).
adaug_sf(E,[],[E]).
adaug_sf(E,[H1|T1],[H1|T2]) :- adaug_sf(E,T1,T2).

%(i,o)
invart([],[]).
invart([H|T1],R) :- invart(T1,R2) , adaug_sf( H , R2 , R).

%(i,o)
next_e(L,R) :- invart(L,R1) , succ(R1,R2,1) , invart(R2,R).

succ([],[],_) :- !.
succ([H|T1] , [H|T2] , N ) :- N = 0 , ! , succ(T1,T2,0).
succ([H|T1] , [M|T2] , N ) :- N > 0 , ! , S is H + N , M is S mod 10 , N1 is S div 10 , succ(T1,T2,N1).

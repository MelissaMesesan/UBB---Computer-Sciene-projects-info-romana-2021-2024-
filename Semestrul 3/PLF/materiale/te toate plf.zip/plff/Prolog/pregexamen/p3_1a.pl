

intercalez([],[],_,_).
intercalez([H|T],[E|[H|T]],1,E).
intercalez([H|T],[H|R],N,E) :- N > 0 , N1 is N - 1 , intercalez(T,R,N1,E).
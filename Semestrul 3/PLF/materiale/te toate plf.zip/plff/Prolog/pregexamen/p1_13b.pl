
elimi([],[],_,_).
elimi([H|T],[H|R],P,N) :- P =\=N , P1 is P + 1 , elimi(T,R,P1,N).
elimi([_|T],R,P,N) :- P = N ,  elimi(T,R,P,N).
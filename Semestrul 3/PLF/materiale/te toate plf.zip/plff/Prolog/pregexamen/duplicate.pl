
este(E,[E|_]).
este(E,[_|T]) :- este(E,T).

duplicate([], []).
duplicate([X|R1], L) :- este(X, R1), duplicate(R1, L).
duplicate([X|R1], [X|R2]) :- duplicate(R1, R2).
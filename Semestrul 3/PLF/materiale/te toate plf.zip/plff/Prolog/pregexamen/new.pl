progr(L,K,R):- findall(S,progr_aux(L,K,S),R).

progr_aux(L,K,R):-candpr(L,E), do_progr(L,K,R,[E],1).

do_progr(_,K,C,C,K):- verif_pr(C).
do_progr(L,K,R,[H|T],LG):-candpr(L,E), H < E, LG1 is LG+1, LG1 =< K, do_progr(L,K,R,[E,H|T],LG1).

candpr([E|_],E).
candpr([_|T],E):- candpr(T,E).

verif_pr([H,H1|T]):- D is H-H1, verif_pr_aux([H1|T],D).

verif_pr_aux([E],_).
verif_pr_aux([H,H1|T],D):- H-H1 =:= D, verif_pr_aux([H1|T],D).
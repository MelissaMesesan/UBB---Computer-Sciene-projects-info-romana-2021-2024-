

produs(_,0,1) :-!.
produs(N,P,Pr) :- P2 is P - 1 , produs(N,P2,Pr2) , Pr is Pr2 * N.

ridic_log(_,0,1) :-!.
ridic_log(A,B,R):- B mod 2 =:= 1 , A2 is A * A , B2 is B div 2 , ridic_log(A2,B2,R2) , R is R2 * A.
ridic_log(A,B,R):- B mod 2 =:= 0 , A2 is A * A , B2 is B div 2 , ridic_log(A2,B2,R2) , R is R2. 


inseram2(E,L,[E|L]).
inseram2(E,[H|T],[H|R]) :- inseram2(E,T,R).

permutare2([],[]).
permutare2([H|T],R) :- permutare2(T,R2) , inseram2(H,R2,R).



perm_total(L,R) :- findall(X , permutare2(L,X) , R).

check([H1,H2|T]):- abs(H1-H2) =< 3 ,check([H2|T]),  !.
check([H1,H2|T]):- abs(H1-H2) > 3 , fail,!.
check([H]):- true.

solve([],[]).
solve([H|T],[H|R]) :- not(number(H)) , check(H) , solve(T,R).
solve([_|T],R) :- solve(T,R).

afis_permutari(L,R) :- perm_total(L,X) , solve(X,R).

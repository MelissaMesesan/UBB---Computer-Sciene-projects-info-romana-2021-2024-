maxim([],-32000).
maxim([H|T],H) :-  maxim(T,M), M < H ,  !.
maxim([_|T],M) :- maxim(T,M).

pozitii([],[]) :-!.
pozitii(L,R) :- maxim(L,M) , find_poz(L,R,M,1).

find_poz([],[],_,_) :- !.
find_poz([H|T],[P|R],M,P) :- H = M , P1 is P + 1 , find_poz(T,R,M,P1).
find_poz([_|T],R,M,P) :- P1 is P + 1 , find_poz(T,R,M,P1).
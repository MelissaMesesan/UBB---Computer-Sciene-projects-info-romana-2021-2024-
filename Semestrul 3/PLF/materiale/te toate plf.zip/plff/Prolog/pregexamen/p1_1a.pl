sterge([],_,[]).
sterge([H|T],E,[H|R] ) :- H =\= E , sterge(T,E,R).
sterge([H|T],E,R) :- H = E , sterge(T,E,R).
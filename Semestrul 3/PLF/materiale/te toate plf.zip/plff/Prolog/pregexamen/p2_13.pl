

adaug(E,[],[E]).
adaug(E,[H|T],[H|R] ) :- adaug(E,T,R).

invart([],[]).
invart([H|T],R) :- invart(T,R1) , adaug(H,R1,R).

afla(L,E,R) :- invart(L,I1) , solve(I1,E,R2,0) , invart(R2,R).

solve([],_,[],_).
solve([],_,[N],N).
solve(T,_,[N|R],N) :- T = [] , N > 0 .
solve([H|T],E,[M|R],N) :- P is E * H + N , M is P mod 10 , N1 is P div 10 , solve(T,E,R,N1). 
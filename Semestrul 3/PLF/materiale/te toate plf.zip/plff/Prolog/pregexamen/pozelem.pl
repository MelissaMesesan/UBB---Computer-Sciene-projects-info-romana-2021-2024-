pozelem([X|_],X,P,P).
pozelem([_|T],X,C,P) :- C1 is C + 1 , pozelem(T,X,C1,P).
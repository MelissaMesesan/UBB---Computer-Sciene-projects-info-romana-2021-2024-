
inte([],L,L).
inte(L,[],L).
inte([H1|T1],[H2|T2],[H1|T3]) :- H1 < H2 , inte(T1,[H2|T2],T3).
inte([H1|T1],[H2|T2],[H2|T3]) :- H2 < H1 , inte([H1|T1],T2,T3).
inte([H1|T1],[H2|T2],[H1|[H2|T3]] ) :- H1 = H2 , inte( T1 , T2 , T3 ).
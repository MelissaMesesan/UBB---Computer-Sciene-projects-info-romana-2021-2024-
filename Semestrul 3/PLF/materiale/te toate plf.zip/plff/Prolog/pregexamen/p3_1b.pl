cmmdc(A,B,A) :-  A = B.
cmmdc(A,B,D) :-  A < B , B1 is B - A , cmmdc(A,B1,D).
cmmdc(A,B,D) :-  A > B , A1 is A - B , cmmdc(A1,B,D).

lcmmdc([],0) :- !.
lcmmdc([E],E) :- !.
lcmmdc([H|T],D) :- lcmmdc(T,D2) , cmmdc(D2, H , D ).

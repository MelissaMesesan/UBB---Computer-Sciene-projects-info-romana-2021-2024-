vale([H1,H2|T]) :- H1 > H2 , cobor([H1|[H2|T]]).
cobor([E]) :- fail.
cobor([H1,H2|T]) :- H1 > H2 , cobor([H2|T]).
cobor([H1,H2|T]) :- H1 < H2 , urc([H1|[H2|T]]).
urc([E]) :- true.
urc([H1,H2|T]) :- H1  < H2 , urc([H2|T]). 
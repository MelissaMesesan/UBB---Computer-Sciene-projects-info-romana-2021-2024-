
minim([],99999).
minim([H|T],H) :- minim(T,M) , H < M , !.
minim([_|T],M) :- minim(T,M).


afla([],[]).
afla(L,R) :- minim(L,M) , solve(L,M,R).

solve([],_,[]).
solve([H|T],M,T) :- H = M.
solve([H|T],M,[H|R] ) :- H =\= M , solve(T,M,R).
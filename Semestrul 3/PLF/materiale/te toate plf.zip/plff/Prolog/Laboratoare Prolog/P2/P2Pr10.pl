%10.Sa se interclaseze fara pastrarea dublurilor 2 liste sortate

%       el=integer
%	list=el*

%	inter(T:list,T1:list,L:list)  (i,i,0)-determinist
%	T=o lista sortata
%	T1=o lista sortata
%	L=interclasarea listelor T si T1 fara dubluri

	inter([],[],[]):-!.
	inter([],L,L):-!.
	inter(L,[],L):-!.
	inter([H|T],[H1|T1],[H|L]):-H<H1,!,inter(T,[H1|T1],L).
	inter([H|T],[H1|T1],[H1|L]):-H>H1,!,inter([H|T],T1,L).
	inter([H|T],[H1|T1],[H|L]):-H=:=H1,inter(T,T1,L).

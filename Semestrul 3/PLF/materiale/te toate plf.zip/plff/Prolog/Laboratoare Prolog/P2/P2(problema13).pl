%produsul unui nr reprezentat pe lista cu o cifra
%[1 9 3 5 9 9]*2-->[3 8 7 1 9 8]
% el:interger
% list el*
%	adauga_sf(E:integer,T:list,T1:list)    (i,i,o) <- determinist
%	  E: elementul ce trebuie adaugat la sfarsit
%	  T: lista in care trebuie adaugat elementul
%	  T1: lista rezultata in urma adaugarii
%	invers(L1:list,L2:list)		  (i,o) <- determinist
%	  L1: lista ce trebuie inversata
%	  L2: lista rezultata in urma inversarii
%	produs(L1:list,E:integer,L2:list)	  (i,i,o) <- determinist
%	  L1: lista de cifre ce reprezinta nr dat
%	  E: cifra cu care se va inmulti numarul
%	  L2: lista formata din cifrele numarului in urma inmultirii
%	prod(L1:list,E1:integer,L2:list,E2:integer)
%              (i,i,o,i) <- determinist
%	  L1: lista de cifre ce reprezinta un nr
%	  E1: cifra cu care se va inmulti numarul
%	  L2: lista formata din cifrele numarului in urma inmultirii
%	  E2: transportul inmultirii


        adauga_sf(E,[],[E]):-!.
	adauga_sf(E,[H|T],[H|L]):-adauga_sf(E,T,L).

	invers([],[]):-!.
	invers([H|T],L):-invers(T,S),adauga_sf(H,S,L).

	produs([],_,[]):-!.
	produs(L,V,LL):-invers(L,L1),prod(L1,V,L2,0),invers(L2,LL).

	prod([],_,[],0):-!.
	prod([],_,[N],N):-!.
	prod([H|T],V,[M|L],N):-N=:=0,!,P=V*H,M is P mod 10,N1 is P div 10,prod(T,V,L,N1).
	prod([H|T],V,[M|L],N):-N=\=0,P=V*H+N,M is P mod 10,N1 is P div 10,prod(T,V,L,N1).













%reuniunea a doua multimi
%
% el:integer
% list el*
%
% apartine(el:integer,T:list)            (i,i) <- determinist
%    el: elementul ce va fi cautat
%    T: lista in care se va cauta
% reuniune(L1:list,L2:list,L3:list)      (i,i,o) <- determinist
%    L1 si L2 : listele ce se vor reuni
%    L3: lista rezultata in urma reuniunii

 apartine(E,[E|T]).
 apartine(E,[H|T]):-apartine(E,T).

 reuniune([],T1,T1).
 reuniune([H2|T2],L2,[H2|T1]):-not(apartine(H2,L2)),reuniune(T2,L2,T1),!.
 reuniune([_|T2],L2,T1):-reuniune(T2,L2,T1).

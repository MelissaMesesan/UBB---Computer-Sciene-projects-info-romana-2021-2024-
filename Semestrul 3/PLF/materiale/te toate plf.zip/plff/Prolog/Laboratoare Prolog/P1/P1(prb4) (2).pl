%4 a. Sa se scrie un predicat care substituie intr-o lista un element prin altul.

 substituire([],_,_,[]):-!.
 substituire(L,E,E,L):-!.
 substituire([H|T],E,X,[H|L]):-H=\=E, substituire(T,E,X,L),!.
 substituire([_|T],E,X,[X|L]):- substituire(T,E,X,L),!.

%4 b. Sa se construiasca sublista (lm, ..., ln) a listei (l1, ..., lk).

  copy(_,_,_,[],[]):-!.
  copy(P,U,Poz,[H|L],[H|T]):-P=<Poz, U>=Poz,Poz1 is Poz+1, copy(P,U,Poz1,L,T),!.
  copy(P,U,Poz,[_|L],T):- Poz1 is Poz+1, copy(P,U,Poz1,L,T),!.

  sublista([],_,_,[]):-!.
  sublista(L,P,U,S):-copy(P,U,1,L,S).

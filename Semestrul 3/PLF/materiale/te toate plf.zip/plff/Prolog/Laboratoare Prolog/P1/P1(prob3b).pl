%  3.  b. Definiti un predicat care intoarce cel mai mare divizor comun al
% numerelor dintr-o lista.
%
%       el:integer
%       list el*
%
%       cmmdc(A:integer,B:integer, D:integer)   %(i,i,o)-determinist
%       A, B numerele pentru care calculam cmmdc
%       D= cmmdc`ul dintre A si B
%
%       cmmdc_sir(T:list,D:integer)  &(i,o)-determinist
%       T=lista pentru care calculam cmmdc
%       D=cmmdc`ul listei

	cmmdc(A,B,A):-A=:=B,!.
	cmmdc(A,B,D):-A<B,!,B1 is B-A,cmmdc(A,B1,D).
	cmmdc(A,B,D):-A>B,A1 is A-B,cmmdc(A1,B,D).

	cmmdc_sir([],0):-!.
	cmmdc_sir([D],D):-!.
	cmmdc_sir([H|T],D):-cmmdc_sir(T,D1),cmmdc(H,D1,D).

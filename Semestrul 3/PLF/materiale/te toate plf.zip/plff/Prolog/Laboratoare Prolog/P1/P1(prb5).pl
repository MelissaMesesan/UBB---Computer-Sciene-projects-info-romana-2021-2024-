%5.
% a. Sa se scrie un predicat care se va satisface daca o lista are numar
% par de elemente si va esua in caz contrar, fara sa se numere
% elementele listei.

  a([]):-!.
 // a([H]):-!.
  a([H1,H2|T]):-a(T).

% b. Sa se elimine prima aparitie a elementului minim dintr-o lista de
% numere intregi.

  minim([],H1,H1):-!.
  minim([H|T],H1,M):- H<H1, minim(T,H,M),!.
  minim([_|T],H1,M):-minim(T,H1,M).

  sterge(_,[],[]):-!.
  sterge(T1,[T1|T],T):-!.
  sterge(T1,[H|T],[H|L]):-sterge(T1,T,L).

  b([],[]):-!.
  b([H],[]):-!.
  b([H1|[H2|T]],L):- minim([H2|T],H1,T1),sterge(T1,[H1|[H2|T]],L).



%cel mai mic multiplu comun al elem unei liste

	cmmdc(A,B,A):-A=:=B.
	cmmdc(A,B,D):-A>B,A1 is A-B,cmmdc(A1,B,D).
	cmmdc(A,B,D):-A<B,B1 is B-A,cmmdc(A,B1,D).

	cmmmc(A,B,M):-cmmdc(A,B,D),M is A*B/D.

	cmmmc_sir([],1).
	cmmmc_sir([H|T],M):-cmmmc_sir(T,M1),cmmmc(H,M1,M).

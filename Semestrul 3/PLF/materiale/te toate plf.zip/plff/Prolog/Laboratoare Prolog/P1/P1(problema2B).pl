%dintr-o lista sa se intoarca multimea tuturor
%perechilor din lista
%     el:integer
%     list el*

%     perechi(E:integer,T:list,T1:list)	(i,i,o)-nedeterminist
%	  E=elementul cu care se vor face perechi
%         T=lista din care se va lua cate un element pentru a face pereche cu E
%	  T1=perechea rezultat

%     multime(T:list,T1:list)	        (i,o)-nedeterminist
%         T=lista cu elemente numere intregi
%         T1=una din perechile rezultat
%     lista(T:list,T1:list)                  (i,o)-determinist
%	  T=lista cu elemente numere intregi
%	  T1=multimea tuturor perechilor din lista


       perechi(E,[H|_],[E,H]).
       perechi(E,[_|T],Rez):-perechi(E,T,Rez).

       multime([H|T],P):-perechi(H,T,P).
       multime([_|T],P):-multime(T,P).

       lista(L, Lp):-findall(P,multime(L,P),Lp).

%1 a. Sa se scrie un predicat care sterge toate aparitiile unui anumit atom
% dintr-o lista.

  sterge([],_,[]).
  sterge([H|T],N,[H|T1]):-N=\=H, sterge(T,N,T1),!.
  sterge([N|T],N,T1):- sterge(T,N,T1),!.

% 1 b. Definiti un predicat care, dintr-o lista de atomi, produce o
% lista de perechi (atom n), unde atom apare in lista initiala de n ori.
% De ex: numar([1, 2, 1, 2, 1, 3, 1], X) va produce X = [[1, 4], [2, 2],
% [3, 1]].

  nr_apar(_,[],0):-!.
  nr_apar(E,[E|H],N):-nr_apar(E,H,N1),N is N1+1,!.
  nr_apar(E,[_|H],N):-nr_apar(E,H,N),!.

  perechi([],[]):-!.
  perechi([E],[[E,1]]):-!.
  perechi([H|T],[H,N|P]):-nr_apar(H,[H|T],N),
                               sterge([H|T],H,L),
			       perechi(L,P),!.

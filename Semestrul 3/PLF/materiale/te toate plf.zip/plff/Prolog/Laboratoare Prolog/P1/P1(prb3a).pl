% 3.
% a. Sa se intercaleze un element pe pozitia a n-a a unei liste.
%
%	el=integer
%	list el*
%
%	interclasare(E:integer,P:integer,T:list,Y:list)
%           (i,i,i,o)-determinist
%	E= numarul care se intercaleaza
%	P= pozitia pe care se intercaleaza E
%	T= lista in care se va intercala E
%	Y=lista finala
%

        intercalare(E,1,[],[E]):-!.
	intercalare(_,_,[],[]):-!.
	intercalare(E,P,T,[E|Y]):-P=:=1,!,P1 is P-1, intercalare(E,P1,T,Y).
	intercalare(E,P,[H|T],[H|Y]):-P>1,!,P1 is P-1, intercalare(E,P1,T,Y).
	intercalare(E,P,[H|T],[H|Y]):-P=:=0, intercalare(E,P,T,Y).


























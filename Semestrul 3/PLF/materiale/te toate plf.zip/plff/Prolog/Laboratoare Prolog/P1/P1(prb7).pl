%9.
%a. Sa se scrie un predicat care transforma o lista intr-o multime, in
% ordinea ultimei aparitii. Exemplu: [1,2,3,1,2] e transformat in
% [3,1,2].
% b. Sa se calculeze cel mai mare divizor comun al elementelor unei
% liste.

apare(E,[E|_]):-!.
apare(E,[_|T]):-apare(E,T).

multime([],[]):-!.
multime([H],[H]):-!.
multime([H|T],R):-multime(T,R),apare(H,R),!.
multime([H|T],[H|R]):-multime(T,R),!.


%    el:integer
%       list el*
%
%       cmmdc(A:integer,B:integer, D:integer)   %(i,i,o)-determinist
%       A, B numerele pentru care calculam cmmdc
%       D= cmmdc`ul dintre A si B
%
%       cmmdc_sir(T:list,D:integer)  &(i,o)-determinist
%       T=lista pentru care calculam cmmdc
%       D=cmmdc`ul listei
	cmmdc(A,B,A):-A=:=B,!.
	cmmdc(A,B,D):-A<B,!,B1 is B-A,cmmdc(A,B1,D).
	cmmdc(A,B,D):-A>B,A1 is A-B,cmmdc(A1,B,D).

	cmmdc_sir([],0):-!.
	cmmdc_sir([D],D):-!.
	cmmdc_sir([H|T],D):-cmmdc_sir(T,D1),cmmdc(H,D1,D).

%7.
% a. Sa se scrie un predicat care transforma o lista intr-o multime, in
% ordinea primei aparitii. Exemplu: [1,2,3,1,2] e transformat in
% [1,2,3].
%

adauga_sf(E,[],[E]):-!.
adauga_sf(E,[H|T],[H|L]):-adauga_sf(E,T,L).

invers([],[]):-!.
invers([H|T],L):-invers(T,S),adauga_sf(H,S,L).

multimee([],[]):-!.
multimee([H],[H]):-!.
multimee(T,R):-invers(T,S),multime(S,L),invers(L,R).

% b. Sa se scrie o functie care descompune o lista de numere
% intr-o lista de forma [ lista-de-numere-pare lista-de-numere-impare]
% (deci lista cu doua elemente care sunt liste de intregi), si va
% intoarce si numarul elementelor pare si impare.

liste([],[],[]):-!.
liste([H|T],[H|P],I ):-H1 is H mod 2,H1=:=0,liste(T,P,I),!.
liste([H|T],P,[H|I] ):-H1 is H mod 2,H1=\=0,liste(T,P,I),!.

lungime([],0):-!.
lungime([H|T],N1):-lungime(T,N),N1 is N+1,!.

prog(T,[P,I],NP,NI):-liste(T,P,I),lungime(P,NP),lungime(I,NI).

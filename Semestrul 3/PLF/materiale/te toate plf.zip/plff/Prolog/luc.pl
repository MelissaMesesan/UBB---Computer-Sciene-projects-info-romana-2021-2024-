%my_write([]).
%my_write([X|R]):- write(X),nl,my_write(R).
%abs(X,Y) :- Y is -X.
%gcd(X,0,X).
%gcd(X,Y,D) :- R is X mod Y , gcd(Y,R,D).

%lcm(X,Y,M) :- gcd(X,Y,D), M is (X*Y)/D.

%a. Sa se scrie un predicat care intoarce reuniunea a doua multimi. 

%(E: number, L: list of numbers)
%is_member (i, i)
is_member( H, [H | _]).
is_member( H, [_ | T] ) :- is_member(H, T), ! .

%(L: list of numbers, K: list of numbers, R: list of numbers)
%reunion (i, i, o) (i, o, i) (o, i, i)
reunion( [], K, K ) :- ! .
reunion( [H|T], K, R ) :- is_member( H, K ), reunion( T, K, R ), ! .
reunion( [H|T], K, [H|R] ) :- reunion( T, K, R ).
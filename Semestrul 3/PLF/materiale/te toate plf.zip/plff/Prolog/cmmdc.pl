cmmdc(A,B,A):- A=B.
cmmdc(A,B,D):- A<B , B1 is B-A , cmmdc(A,B1,D).
cmmdc(A,B,D):- A>B ,A1 is A-B, cmmdc(A1,B,D).
	
cmmmc(A,B,M):- P is	 A*B , cmmdc(A,B,D) , M is P div D.

cmmmcL([],1).
cmmmcL([H|T],M):-cmmmcL(T,M1),cmmmc(H,M1,M).
 
%cmmdc_list([],0):- write(toader), !.
%cmmdc_list([D],D):- !.
%cmmdc_list([H|T],D):-cmmdc_list(T,D1),cmmdc(H,D1,D) ,!.

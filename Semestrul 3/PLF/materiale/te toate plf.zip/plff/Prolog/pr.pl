%sa se sorteze o lista cu pastrarea dublurilor
domains
	el=integer
	list=el*
predicates
	sortare(list,list)
	insert(el,list,list)

clauses
	insert(E,[],[E]).
	insert(E,[H|T],[E|[H|T]]):-E<=H,!.
	insert(E,[H|T],[H|L]):-E>H,insert(E,T,L).

	sortare([],[]).
	sortare([H|T],L):-sortare(T,L1),insert(H,L1,L).

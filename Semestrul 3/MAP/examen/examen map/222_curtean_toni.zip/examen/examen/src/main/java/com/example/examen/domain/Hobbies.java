package com.example.examen.domain;

public enum Hobbies {
    READING,MUSIC,HIKING,WALKING,EXTREMESPORTS
}

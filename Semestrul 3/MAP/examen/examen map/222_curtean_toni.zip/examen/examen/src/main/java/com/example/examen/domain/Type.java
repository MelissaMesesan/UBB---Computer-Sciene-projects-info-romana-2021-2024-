package com.example.examen.domain;

public enum Type {
    FAMILY,TEENAGERS,OLDPEOPLE
}

package com.example.clinique.utils.events;

public interface Event {
}

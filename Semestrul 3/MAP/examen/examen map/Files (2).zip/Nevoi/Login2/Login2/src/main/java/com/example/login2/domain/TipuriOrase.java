package com.example.login2.domain;

public enum TipuriOrase {
    Cluj,
    Bistrita,
    Sibiu,
    Brasov
}

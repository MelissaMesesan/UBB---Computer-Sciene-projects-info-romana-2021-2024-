package com.example.login2.repository.factory;

public enum RepositoryEntity {
    PERSOANE,
    NEVOI

}

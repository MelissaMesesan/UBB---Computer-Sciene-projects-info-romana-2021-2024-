package com.example.subiect4.service;

import com.example.subiect4.database.PersoanaDataBaseRepository;
import com.example.subiect4.domain.Persoana;

import java.util.List;

public class PersoanaService {

    private PersoanaDataBaseRepository persoanaDataBaseRepository;

    public PersoanaService(PersoanaDataBaseRepository persoanaDataBaseRepository){
        this.persoanaDataBaseRepository = persoanaDataBaseRepository;
    }

    public Persoana addPersoana(Persoana persoana) {
        return persoanaDataBaseRepository.addPersoana(persoana);
    }

    public List<Persoana> getAllPersoane() {
        return persoanaDataBaseRepository.getAllPersoane();
    }

    public boolean verifyIfAPersonExist(String username){
        return persoanaDataBaseRepository.verifyIfAPersonExist(username);
    }


    public long getMaxId(){
        return persoanaDataBaseRepository.getMaxId();
    }


    public Persoana findOnePersoana(long idPersoana){
        return persoanaDataBaseRepository.findOnePersoana(idPersoana);
    }

}

package com.example.subiect4.utils.events;

public interface Event {
}

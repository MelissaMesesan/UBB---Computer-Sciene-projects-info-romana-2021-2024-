package com.example.subiect4.utils.events;

import com.example.subiect4.domain.Nevoie;

public class NevoieEntityChangeEvent implements Event {
    private final ChangeEventType type;
    private final Nevoie data;
    private Nevoie oldData;

    public NevoieEntityChangeEvent(ChangeEventType type, Nevoie data) {
        this.type = type;
        this.data = data;
    }

    public NevoieEntityChangeEvent(ChangeEventType type, Nevoie data, Nevoie oldData) {
        this.type = type;
        this.data = data;
        this.oldData = oldData;
    }

    public ChangeEventType getType() {
        return type;
    }

    public Nevoie getData() {
        return data;
    }

    public Nevoie getOldData() {
        return oldData;
    }
}
package com.example.subiect4;

import com.example.subiect4.database.NevoieDataBaseRepository;
import com.example.subiect4.database.PersoanaDataBaseRepository;
import com.example.subiect4.domain.Persoana;
import com.example.subiect4.service.NevoieService;
import com.example.subiect4.service.PersoanaService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class LogInController {


    private ObservableList<Persoana> persoaneModel = FXCollections.observableArrayList();

    private LogInController logInController;

    private Stage logInStage;

    private PersoanaService persoanaService;

    @FXML
    private ListView<Persoana> listaDePersoane;

    @FXML
    public void initialize() {
        listaDePersoane.setItems(persoaneModel);
    }

    @FXML
    public void onPersonSelected() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("tabs-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);

        Stage tabsStage = new Stage();

        tabsStage.setTitle("Tabs");
        tabsStage.setScene(scene);

        NevoieDataBaseRepository nevoieDataBaseRepository = new NevoieDataBaseRepository();
        NevoieService nevoieService = new NevoieService(nevoieDataBaseRepository);

        TabsController tabsController = fxmlLoader.getController();
        tabsController.setNevoieStage(tabsStage);
        tabsController.setPersoanaService(persoanaService);
        tabsController.setNevoieService(nevoieService);
        tabsController.setPersoanaLogata(listaDePersoane.getSelectionModel().getSelectedItem());
        tabsController.setNevoiTable();
        tabsController.setFapteBuneTable();

        tabsStage.show();

    }

    @FXML
    public void onSignUpButtonClicked() throws IOException {

        logInStage.close();

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("signUp-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);

        Stage signUpStage = new Stage();

        signUpStage.setTitle("SignUp");
        signUpStage.setScene(scene);

        PersoanaDataBaseRepository persoanaDataBaseRepository = new PersoanaDataBaseRepository();
        PersoanaService persoanaService = new PersoanaService(persoanaDataBaseRepository);

        SignUpController signUpController = fxmlLoader.getController();
        signUpController.setPersoanaService(persoanaService);
        signUpController.setAllOrase();
        signUpController.setLogInStage(logInStage);
        signUpController.setSignUpStage(signUpStage);
        signUpController.setLogInController(logInController);

        signUpStage.show();

    }

    public void setLogInStage(Stage logInStage) {
        this.logInStage = logInStage;
    }

    public void setPersoanaService(PersoanaService persoanaService) {
        this.persoanaService = persoanaService;
    }

    public void setListaDePersoane() {
        List<Persoana> persoane = persoanaService.getAllPersoane();
        persoaneModel.setAll(persoane);
    }

    public void setLogInController(LogInController logInController){
        this.logInController = logInController;
    }


}
